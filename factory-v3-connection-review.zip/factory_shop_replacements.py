﻿import re
import html
from pathlib import Path
from urllib.parse import quote

MASTER = Path(r"E:\massage-auto-test").resolve()
LIVE = Path(r"E:\seoul-massage-rebuild").resolve()

IDS = {"001", "002", "003", "004", "005"}

SHOP_OLD_PHONES = {
    "오늘밤테라피": "0507-1280-3353",
    "쥬쥬테라피": "0507-1280-3354",
    "퀸즈테라피": "0507-1280-3357",
    "한국미인테라피": "0507-1280-3355",
    "한국인골든테라피": "0507-1280-3359",
    "S슬립테라피": "0507-1280-3356",
    "대구테라피": "0507-1280-3027",
    "나비테라피": "0507-1284-8225",
    "끌림테라피": "0507-1284-8168",
    "레이디테라피": "0507-1280-3277",
    "로제테라피": "0507-1280-3277",
    "상큼테라피": "0507-1280-3005",
    "다온테라피": "0507-1284-8030",
}

H1_RE = re.compile(
    r'<h1\b[^>]*>(.*?)</h1>',
    re.I | re.S
)

TEXT_EXTENSIONS = {
    ".html", ".xml", ".txt",
    ".css", ".js", ".json"
}


def clean_html(value):
    return html.unescape(
        re.sub(r"<[^>]+>", "", value)
    ).strip()


def digits(value):
    return re.sub(r"\D", "", str(value or ""))


def formatted_phone(value, separator="-"):
    d = digits(value)

    if len(d) == 12 and d.startswith("0507"):
        parts = [d[:4], d[4:8], d[8:]]

    elif len(d) == 11:
        parts = [d[:3], d[3:7], d[7:]]

    elif len(d) == 10:
        parts = [d[:3], d[3:6], d[6:]]

    else:
        return d

    return separator.join(parts)


def replace_phone(text, old_phone, new_phone):

    old_digits = digits(old_phone)
    new_digits = digits(new_phone)

    if not old_digits or not new_digits:
        return text, 0

    pattern = re.compile(
        r'(?<!\d)'
        + r'[-\s]*'.join(
            re.escape(ch)
            for ch in old_digits
        )
        + r'(?!\d)'
    )

    count = 0

    def repl(match):
        nonlocal count
        count += 1

        original = match.group(0)

        if "-" in original:
            return formatted_phone(
                new_digits,
                "-"
            )

        if " " in original:
            return formatted_phone(
                new_digits,
                " "
            )

        return new_digits

    return pattern.sub(repl, text), count


def apply_shop_replacements(root, cfg):

    root = Path(root).resolve()

    if (
        root == MASTER
        or root.is_relative_to(MASTER)
        or root == LIVE
        or root.is_relative_to(LIVE)
    ):
        raise RuntimeError(
            "마스터 또는 운영 사이트는 수정할 수 없습니다."
        )

    settings = cfg.get(
        "shop_replacements",
        {}
    ) or {}

    if not settings:
        print("업체별 변경 설정 없음")
        return {
            "configured": 0,
            "name_changes": 0,
            "phone_changes": 0,
            "pages": 0,
        }

    unknown = sorted(
        set(settings)
        - set(SHOP_OLD_PHONES)
    )

    if unknown:
        raise RuntimeError(
            "등록되지 않은 기존 업체명: "
            + ", ".join(unknown)
        )

    numeric_files = sorted(
        p for p in root.rglob("index.html")
        if p.parent.name in IDS
        and p.parent.parent.name == "shops"
    )

    page_old_names = {}
    inventory = {}

    for path in numeric_files:

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        m = H1_RE.search(text)

        if not m:
            raise RuntimeError(
                "H1 없음: " + str(path)
            )

        name = clean_html(m.group(1))

        page_old_names[path] = name
        inventory[name] = (
            inventory.get(name, 0) + 1
        )

    for old_name in settings:

        if inventory.get(old_name, 0) == 0:
            raise RuntimeError(
                f"대상 업체 페이지 없음: {old_name}"
            )

    resolved = {}

    for old_name, item in settings.items():

        item = item or {}

        new_name = str(
            item.get("name") or old_name
        ).strip()

        new_phone = str(
            item.get("phone") or ""
        ).strip()

        resolved[old_name] = {
            "name": new_name,
            "phone": new_phone,
            "old_phone": SHOP_OLD_PHONES[old_name],
        }

    # ---------------------------------
    # 1. 업체명은 전체 사이트 텍스트에서 변경
    # URL, canonical, sitemap, 링크텍스트까지 동기화
    # ---------------------------------

    name_pairs = []

    for old_name, item in resolved.items():

        new_name = item["name"]

        if new_name == old_name:
            continue

        name_pairs.append(
            (old_name, new_name)
        )

        encoded_old = quote(
            old_name,
            safe=""
        )

        encoded_new = quote(
            new_name,
            safe=""
        )

        name_pairs.append(
            (encoded_old, encoded_new)
        )

        name_pairs.append(
            (encoded_old.lower(), encoded_new)
        )

    name_changes = 0
    name_files = 0

    if name_pairs:

        for path in root.rglob("*"):

            if not path.is_file():
                continue

            if path.suffix.lower() not in TEXT_EXTENSIONS:
                continue

            text = path.read_text(
                encoding="utf-8",
                errors="ignore"
            )

            original = text
            changes_here = 0

            for old, new in name_pairs:

                n = text.count(old)

                if n:
                    text = text.replace(
                        old,
                        new
                    )
                    changes_here += n

            if changes_here:

                path.write_text(
                    text,
                    encoding="utf-8"
                )

                name_files += 1
                name_changes += changes_here

    # ---------------------------------
    # 2. 전화번호는 해당 업체 숫자 원본에서만 변경
    # 같은 기존 번호를 공유해도 업체별 분리 가능
    # ---------------------------------

    phone_changes = 0
    phone_files = 0
    affected_pages = 0

    for path, old_name in page_old_names.items():

        if old_name not in resolved:
            continue

        item = resolved[old_name]
        new_phone = item["phone"]

        if not new_phone:
            continue

        old_phone = item["old_phone"]

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        new_text, count = replace_phone(
            text,
            old_phone,
            new_phone
        )

        if count:

            path.write_text(
                new_text,
                encoding="utf-8"
            )

            phone_files += 1
            phone_changes += count
            affected_pages += 1

    # ---------------------------------
    # 3. 결과 검증
    # ---------------------------------

    errors = []

    for path, old_name in page_old_names.items():

        if old_name not in resolved:
            continue

        item = resolved[old_name]

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        m = H1_RE.search(text)

        if not m:
            errors.append(
                "변경 후 H1 없음: " + str(path)
            )
            continue

        actual_name = clean_html(
            m.group(1)
        )

        if actual_name != item["name"]:
            errors.append(
                f"H1 불일치: {path} "
                f"예상={item['name']} "
                f"실제={actual_name}"
            )

        if item["phone"]:

            old_digits = digits(
                item["old_phone"]
            )

            new_digits = digits(
                item["phone"]
            )

            normalized = re.sub(
                r"(?<=\d)[\s-](?=\d)",
                "",
                text
            )

            if old_digits in normalized:
                errors.append(
                    "기존 전화번호 잔존: "
                    + str(path)
                )

            if new_digits not in normalized:
                errors.append(
                    "새 전화번호 없음: "
                    + str(path)
                )

    print()
    print("===== 실제 업체명 기준 변경 =====")

    print("설정 업체 수       :", len(resolved))
    print("업체명 수정 파일   :", name_files)
    print("업체명 총 치환     :", name_changes)
    print("전화 수정 파일     :", phone_files)
    print("전화 총 치환       :", phone_changes)
    print("전화 변경 업체페이지:", affected_pages)
    print("검증 오류          :", len(errors))

    if errors:

        for error in errors[:20]:
            print(error)

        raise RuntimeError(
            "업체정보 변경 검증 실패"
        )

    return {
        "configured": len(resolved),
        "name_changes": name_changes,
        "phone_changes": phone_changes,
        "pages": affected_pages,
    }
