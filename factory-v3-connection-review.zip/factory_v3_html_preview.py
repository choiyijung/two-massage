﻿import re
import html
import shutil
from pathlib import Path

MASTER = Path(r"E:\massage-auto-test")
OUTPUT = Path(r"D:\massage-sites")

SAMPLES = [
    "index.html",
    "massage/seoul/index.html",
    "massage/seoul/gangnam-gu/index.html",
    "massage/gyeonggi/ansan/index.html",
    "special/seoul/index.html",
]

PROFILES = ["A", "B"]

P_RE = re.compile(
    r"(<p\b[^>]*>)(.*?)(</p>)",
    re.I | re.S
)

H1_RE = re.compile(
    r"(<h1\b[^>]*>)(.*?)(</h1>)",
    re.I | re.S
)

TITLE_RE = re.compile(
    r"(<title\b[^>]*>)(.*?)(</title>)",
    re.I | re.S
)

META_RE = re.compile(
    r"<meta\b[^>]*>",
    re.I | re.S
)


def clean(value):
    return re.sub(
        r"\s+",
        " ",
        html.unescape(
            re.sub(r"<[^>]+>", " ", value)
        )
    ).strip()


def meta_update(text, key, value):

    changed = 0

    def replace_tag(match):
        nonlocal changed

        tag = match.group(0)

        attr = re.search(
            r'\b(?:name|property)\s*=\s*(["\'])(.*?)\1',
            tag,
            re.I | re.S
        )

        if not attr or attr.group(2).lower() != key:
            return tag

        content_re = re.compile(
            r'(\bcontent\s*=\s*)(["\'])(.*?)\2',
            re.I | re.S
        )

        new_tag, count = content_re.subn(
            lambda m:
                m.group(1)
                + m.group(2)
                + html.escape(value, quote=True)
                + m.group(2),
            tag,
            count=1
        )

        changed += count

        return new_tag

    updated = META_RE.sub(replace_tag, text)

    if changed != 1:
        raise RuntimeError(
            f"메타태그 확인 필요: {key}, 개수={changed}"
        )

    return updated


def replace_p(text, number, value):

    matches = list(P_RE.finditer(text))

    if len(matches) < number:
        raise RuntimeError(
            f"P 태그가 부족합니다: {number}"
        )

    match = matches[number - 1]

    replacement = (
        match.group(1)
        + html.escape(value)
        + match.group(3)
    )

    return (
        text[:match.start()]
        + replacement
        + text[match.end():]
    )


def get_context(text):

    paragraphs = [
        clean(m.group(2))
        for m in P_RE.finditer(text)
    ]

    if len(paragraphs) < 4:
        raise RuntimeError(
            "지역 본문 구조가 예상과 다릅니다."
        )

    area_match = re.fullmatch(
        r"(.+?)\s+생활권 정보",
        paragraphs[2]
    )

    place_match = re.search(
        r"^(.+?)\s+생활권을 기준",
        paragraphs[1]
    )

    if not area_match or not place_match:
        raise RuntimeError(
            "지역정보 추출 실패"
        )

    area = area_match.group(1)

    places = [
        x.strip()
        for x in re.split(
            r",\s*|와\s+|과\s+",
            place_match.group(1)
        )
        if x.strip()
    ]

    if len(places) < 2:
        raise RuntimeError(
            "생활권 정보가 부족합니다."
        )

    place_text = "·".join(places)

    scene_match = re.search(
        r"^(.+?)\s+뒤에는",
        paragraphs[3]
    )

    scene = (
        scene_match.group(1)
        if scene_match
        else ""
    )

    return area, place_text, scene


def generate(relative, text, profile):

    title_match = TITLE_RE.search(text)
    h1_match = H1_RE.search(text)

    if not title_match or not h1_match:
        raise RuntimeError(
            f"TITLE 또는 H1 없음: {relative}"
        )

    old_title = clean(title_match.group(2))
    old_h1 = clean(h1_match.group(2))

    brand = "전국클린마사지"

    if relative == "index.html":

        if "|" in old_h1:
            brand = old_h1.split("|")[-1].strip()

        if profile == "A":

            title = (
                f"전국 마사지 지역별 안내 | "
                f"{brand}"
            )

            description = (
                "서울·경기·인천과 주요 도시의 마사지 "
                "지역정보를 확인하세요. 권역별 안내에서 "
                "시·군·구를 선택하고 세부 지역과 "
                "연결된 업체정보를 살펴볼 수 있습니다."
            )

            h1 = (
                f"전국 마사지 지역 찾기 | {brand}"
            )

            intro = (
                "현재 위치에 가까운 마사지 지역부터 "
                "찾아보세요. 서울·경기·인천을 비롯한 "
                "주요 도시를 선택하면 지역별 안내와 "
                "연결된 업체정보를 차례로 확인할 수 있습니다."
            )

        else:

            title = (
                f"{brand} | "
                "마사지 코스와 전국 지역 이용정보"
            )

            description = (
                "마사지 이용을 준비할 때 참고할 수 있는 "
                "전국 지역 안내입니다. 이용하려는 지역을 "
                "찾고 업체별 코스와 문의방법, "
                "예약 전 확인사항을 살펴보세요."
            )

            h1 = (
                f"마사지 이용정보와 코스 안내 | {brand}"
            )

            intro = (
                "마사지 이용을 알아보고 있다면 "
                "지역과 코스정보를 함께 확인해보세요. "
                "원하는 지역을 선택한 뒤 업체별 안내에서 "
                "이용시간과 문의 전 확인할 내용을 "
                "살펴볼 수 있습니다."
            )

        paragraphs = {
            1: intro
        }

    elif relative.startswith("massage/") and (
        relative.count("/") >= 3
    ):

        area, places, scene = get_context(text)

        topic = old_title.split("|")[0].strip()

        if profile == "A":

            title = (
                f"{area} 마사지 생활권 안내 | "
                f"{places} 지역 찾기"
            )

            description = (
                f"{area}의 {places} 생활권을 중심으로 "
                "세부 지역정보를 정리했습니다. "
                "현재 위치와 가까운 지역을 선택하고 "
                "연결된 업체별 이용안내를 확인해보세요."
            )

            h1 = (
                f"{area}에서 가까운 생활권 찾아보기"
            )

            intro = (
                f"{area}의 {places} 지역을 기준으로 "
                "생활권을 살펴보세요. "
                "이동하려는 위치에 맞춰 세부 지역을 "
                "확인하고 업체별 안내로 이어질 수 있습니다."
            )

            detail = (
                f"{area}에는 {places} 등 "
                "서로 다른 생활권이 연결되어 있습니다. "
                "현재 위치에서 가까운 지역을 먼저 확인하고 "
                "필요하면 주변 지역까지 범위를 넓혀 "
                "비교해보세요."
            )

        else:

            title = (
                f"{topic} 이용 전 확인 | "
                f"{area} 지역 안내"
            )

            description = (
                f"{area}에서 마사지 이용을 준비한다면 "
                f"{places} 등 희망 지역을 정해보세요. "
                "업체별 코스와 문의방법을 살펴보고 "
                "이용 가능 여부를 확인할 수 있습니다."
            )

            h1 = (
                f"{area} 마사지 이용을 준비한다면"
            )

            intro = (
                f"{area}에서 마사지 이용을 알아볼 때는 "
                "방문 위치와 희망 시간부터 정리하는 것이 "
                "편리합니다. "
                f"{places} 중 이용하려는 지역을 선택하고 "
                "연결된 업체정보를 살펴보세요."
            )

            detail = (
                f"{area}에서 이용 일정을 계획한다면 "
                "원하는 코스와 시간을 먼저 확인해보세요. "
                "지역별 안내에 연결된 업체 페이지를 "
                "참고한 뒤 실제 가능한 일정과 이용방법을 "
                "상담 과정에서 확인할 수 있습니다."
            )

        paragraphs = {
            2: intro,
            4: detail
        }

    else:

        is_special = relative.startswith(
            "special/"
        )

        parts = Path(relative).parts

        area_names = {
            "seoul": "서울",
            "gyeonggi": "경기",
            "incheon": "인천",
            "other": "기타 지역",
        }

        area = area_names.get(
            parts[1],
            ""
        )

        if not area:
            raise RuntimeError(
                f"권역을 확인할 수 없습니다: {relative}"
            )

        category = (
            "출장 마사지"
            if is_special
            else "마사지"
        )

        if profile == "A":

            title = (
                f"{area} {category} 지역 찾기 | "
                "세부 지역별 안내"
            )

            description = (
                f"{area}의 {category} 지역정보를 "
                "확인하세요. 구·시·군을 선택한 뒤 "
                "세부 지역과 연결된 업체정보를 "
                "살펴볼 수 있습니다."
            )

            h1 = (
                f"{area} {category} 지역별 안내"
            )

            intro = (
                f"{area}에서 이용하려는 지역을 "
                "찾아보세요. 구·시·군별로 정리된 "
                "목록에서 현재 위치에 가까운 곳을 "
                "선택하면 세부 지역정보를 "
                "확인할 수 있습니다."
            )

        else:

            title = (
                f"{area} {category} 이용 준비 | "
                "지역 선택과 문의정보"
            )

            description = (
                f"{area}에서 {category} 이용을 "
                "준비할 때 참고할 안내입니다. "
                "희망 지역을 정하고 업체별 코스와 "
                "문의 전 확인사항을 살펴보세요."
            )

            h1 = (
                f"{area}에서 {category} 이용을 알아본다면"
            )

            intro = (
                f"{area} {category} 이용을 "
                "준비한다면 먼저 원하는 지역을 "
                "선택해보세요. 연결된 업체별 안내에서 "
                "코스정보와 문의방법을 살펴보고 "
                "이용 전 확인할 내용을 정리할 수 있습니다."
            )

        paragraphs = {
            2: intro
        }

    # TITLE
    updated, n = TITLE_RE.subn(
        lambda m:
            m.group(1)
            + html.escape(title)
            + m.group(3),
        text,
        count=1
    )

    if n != 1:
        raise RuntimeError(
            f"TITLE 수정 실패: {relative}"
        )

    # DESCRIPTION 및 SNS 메타
    for key, value in [
        ("description", description),
        ("og:title", title),
        ("og:description", description),
    ]:

        updated = meta_update(
            updated,
            key,
            value
        )

    # H1
    updated, n = H1_RE.subn(
        lambda m:
            m.group(1)
            + html.escape(h1)
            + m.group(3),
        updated,
        count=1
    )

    if n != 1:
        raise RuntimeError(
            f"H1 수정 실패: {relative}"
        )

    # 안내문만 수정, 지역 링크와 업체 카드는 보존
    for number, value in paragraphs.items():

        updated = replace_p(
            updated,
            number,
            value
        )

    return updated, {
        "title": title,
        "description": description,
        "h1": h1,
        "paragraphs": paragraphs,
    }


def main():

    results = []

    for profile in PROFILES:

        target = (
            OUTPUT
            / f"v3-content-preview-{profile}"
        )

        if target.exists():
            raise RuntimeError(
                f"미리보기 폴더가 이미 있습니다: {target}"
            )

        for relative in SAMPLES:

            source = MASTER / relative

            if not source.is_file():
                raise RuntimeError(
                    f"원본 파일 없음: {source}"
                )

            text = source.read_text(
                encoding="utf-8",
                errors="ignore"
            )

            generated, info = generate(
                relative,
                text,
                profile
            )

            if generated == text:
                raise RuntimeError(
                    f"수정되지 않은 페이지: {relative}"
                )

            results.append(
                (
                    profile,
                    relative,
                    generated,
                    info
                )
            )

    # 모든 페이지 생성 가능 여부를 확인한 후 저장
    for profile, relative, generated, info in results:

        target = (
            OUTPUT
            / f"v3-content-preview-{profile}"
            / relative
        )

        target.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        target.write_text(
            generated,
            encoding="utf-8"
        )

    print("=" * 72)
    print("V3 A/B 실제 HTML 콘텐츠 시험판 완료")
    print("=" * 72)

    for profile, relative, generated, info in results:

        print()
        print("유형:", profile)
        print("파일:", relative)
        print("TITLE:", info["title"])
        print("DESCRIPTION:", info["description"])
        print("H1:", info["h1"])

        for number, paragraph in info["paragraphs"].items():

            print(
                f"본문 P{number}:",
                paragraph
            )

    print()
    print("생성 HTML:", len(results))

    for profile in PROFILES:

        print(
            "저장 위치:",
            OUTPUT / f"v3-content-preview-{profile}"
        )

    print()
    print("마스터 HTML 변경: 없음")
    print("V2 제작기 변경: 없음")
    print("기존 운영 사이트 변경: 없음")


if __name__ == "__main__":
    main()
