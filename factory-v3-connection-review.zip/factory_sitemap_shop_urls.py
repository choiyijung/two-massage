﻿import html
import os
import re
import xml.etree.ElementTree as ET

from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
from xml.sax.saxutils import escape

from factory_public_urls import get_canonical


IDS = {"001", "002", "003", "004", "005"}

MASTER = Path(r"E:\massage-auto-test").resolve()
LIVE = Path(r"E:\seoul-massage-rebuild").resolve()


class RobotReader(HTMLParser):

    def __init__(self):
        super().__init__()
        self.noindex = False

    def handle_starttag(self, tag, attrs):

        if tag.lower() != "meta":
            return

        attrs = {
            str(k).lower(): (v or "")
            for k, v in attrs
        }

        if attrs.get("name", "").lower() not in {
            "robots",
            "googlebot",
            "naverbot"
        }:
            return

        if re.search(
            r"(^|[\s,;])noindex($|[\s,;])",
            attrs.get("content", "").lower()
        ):
            self.noindex = True


def url_key(url):

    parsed = urlsplit(
        html.unescape(url).strip()
    )

    return (
        parsed.netloc.lower(),
        unquote(parsed.path).rstrip("/") + "/"
    )


def sync_indexable_shop_urls(root):

    root = Path(root).resolve()

    if root in {MASTER, LIVE}:
        raise RuntimeError(
            "마스터 또는 운영 사이트는 수정할 수 없습니다."
        )

    if not root.is_dir():
        raise RuntimeError(
            "생성된 테스트 폴더가 없습니다."
        )

    sitemap = root / "sitemap.xml"

    if not sitemap.is_file():
        raise RuntimeError(
            "sitemap.xml이 없습니다."
        )

    original = sitemap.read_text(
        encoding="utf-8-sig"
    )

    tree = ET.fromstring(original)

    existing = set()
    sitemap_hosts = set()

    for element in tree.iter():

        if element.tag.rsplit("}", 1)[-1] != "loc":
            continue

        if not element.text:
            continue

        k = url_key(element.text)

        existing.add(k)
        sitemap_hosts.add(k[0])

    if len(sitemap_hosts) != 1:
        raise RuntimeError(
            f"sitemap 도메인을 확인해야 합니다: {sitemap_hosts}"
        )

    files = sorted(
        p for p in root.rglob("index.html")
        if p.parent.name in IDS
        and p.parent.parent.name == "shops"
    )

    additions = {}
    checked = 0
    noindex_skipped = 0

    for path in files:

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        canonical = get_canonical(text)

        if not canonical:
            raise RuntimeError(
                f"canonical 없음: {path}"
            )

        parsed = urlsplit(canonical)

        if (
            parsed.scheme not in {"http", "https"}
            or parsed.netloc.lower() not in sitemap_hosts
            or not parsed.path.startswith("/")
            or not parsed.path.endswith("/")
            or parsed.query
            or parsed.fragment
        ):
            raise RuntimeError(
                f"canonical 확인 필요: {canonical}"
            )

        reader = RobotReader()
        reader.feed(text)

        checked += 1

        if reader.noindex:
            noindex_skipped += 1
            continue

        k = url_key(canonical)

        if k in existing:
            continue

        if (
            k in additions
            and additions[k] != canonical
        ):
            raise RuntimeError(
                f"공개 URL 중복: {canonical}"
            )

        additions[k] = canonical

    print("=" * 72)
    print("전국 업체 상세페이지 sitemap 보완")
    print("=" * 72)

    print("검사 업체 페이지 :", checked)
    print("기존 sitemap URL :", len(existing))
    print("noindex 제외     :", noindex_skipped)
    print("새로 추가할 URL  :", len(additions))

    if not additions:
        print("추가할 URL이 없습니다.")
        return {
            "added": 0,
            "total": len(existing)
        }

    namespace = ""

    if tree.tag.startswith("{"):
        namespace = tree.tag.split("}", 1)[0][1:]

    closing = re.search(
        r"</(?:[A-Za-z_][\w.-]*:)?urlset\s*>\s*$",
        original,
        re.I
    )

    if not closing:
        raise RuntimeError(
            "sitemap 닫는 태그를 찾지 못했습니다."
        )

    lines = []

    for canonical in additions.values():

        safe_url = escape(canonical)

        lines.append(
            "  <url><loc>"
            + safe_url
            + "</loc></url>"
        )

    insertion = "\n" + "\n".join(lines) + "\n"

    updated = (
        original[:closing.start()]
        + insertion
        + original[closing.start():]
    )

    # 저장하기 전에 XML 구조 검사
    verified = ET.fromstring(updated)

    verified_urls = {
        url_key(e.text)
        for e in verified.iter()
        if e.tag.rsplit("}", 1)[-1] == "loc"
        and e.text
    }

    expected = existing | set(additions)

    if verified_urls != expected:
        raise RuntimeError(
            "sitemap 저장 전 URL 검증 실패"
        )

    temp = root / "sitemap.xml.shopurls.tmp"

    if temp.exists():
        raise RuntimeError(
            "임시 sitemap 파일이 이미 있습니다."
        )

    try:

        temp.write_text(
            updated,
            encoding="utf-8"
        )

        ET.parse(temp)

        os.replace(temp, sitemap)

    finally:

        if temp.exists():
            temp.unlink()

    print("실제 추가 URL    :", len(additions))
    print("최종 sitemap URL :", len(verified_urls))

    return {
        "added": len(additions),
        "total": len(verified_urls)
    }
