﻿import re
import json
import html
from pathlib import Path
from collections import Counter, defaultdict

import factory_v3_html_preview as base
import factory_v3_region_engine as old

ROOT = Path(r"E:\massage-auto-test")

REGION_NAME = {
    "seoul": "서울",
    "gyeonggi": "경기",
    "incheon": "인천",
    "other": "",
}

P_RE = re.compile(
    r"(<p\b[^>]*>)(.*?)(</p>)",
    re.I | re.S
)

TITLE_RE = re.compile(
    r"(<title\b[^>]*>)(.*?)(</title>)",
    re.I | re.S
)

H1_RE = re.compile(
    r"(<h1\b[^>]*>)(.*?)(</h1>)",
    re.I | re.S
)


def clean(value):
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(
        r"\s+", " ",
        html.unescape(value)
    ).strip()


def breadcrumbs(text):
    scripts = re.findall(
        r'<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
        text,
        re.I | re.S
    )

    for script in scripts:
        try:
            data = json.loads(script.strip())
        except Exception:
            continue

        objects = data if isinstance(data, list) else [data]

        for obj in objects:
            if not isinstance(obj, dict):
                continue

            if "@graph" in obj:
                objects.extend(
                    x for x in obj["@graph"]
                    if isinstance(x, dict)
                )

            kind = obj.get("@type", "")

            if kind != "BreadcrumbList":
                continue

            names = []

            for item in obj.get("itemListElement", []):
                name = item.get("name", "")

                if name and name not in {
                    "홈", "HOME", "전체 지역"
                }:
                    names.append(name.strip())

            if names:
                return names

    return []


def context(relative, text):
    matches = list(P_RE.finditer(text))

    paragraphs = [
        clean(m.group(2))
        for m in matches
    ]

    label_index = None
    short_area = None

    for index, value in enumerate(paragraphs):
        match = re.fullmatch(
            r"(.+?)\s+생활권 정보",
            value
        )

        if match:
            label_index = index
            short_area = match.group(1).strip()
            break

    if label_index is None:
        raise ValueError(
            "생활권 정보 문단을 찾을 수 없음"
        )

    if label_index < 1:
        raise ValueError(
            "소개문 위치를 찾을 수 없음"
        )

    parts = Path(relative).parts
    region = REGION_NAME[parts[1]]

    names = breadcrumbs(text)

    if not names:
        raise ValueError(
            "상위 지역을 확인할 BreadcrumbList 없음"
        )

    if names[-1] != short_area:
        if short_area not in names[-1]:
            names.append(short_area)

    full_area = " ".join(names)

    if region and not full_area.startswith(region):
        full_area = region + " " + full_area

    places = old.get_places(text)

    return {
        "area": full_area,
        "short_area": short_area,
        "intro_index": label_index - 1,
        "detail_index": (
            label_index + 1
            if label_index + 1 < len(matches)
            else None
        ),
        "places": places,
        "p_count": len(matches),
    }


def replace_p_at(text, index, value):
    matches = list(P_RE.finditer(text))

    if index >= len(matches):
        raise ValueError(
            "본문 교체 위치가 없습니다"
        )

    match = matches[index]

    replacement = (
        match.group(1)
        + html.escape(value)
        + match.group(3)
    )

    return (
        text[:match.start()]
        + replacement
        + text[match.end():]
    )


def replace_once(pattern, text, value, name):
    updated, count = pattern.subn(
        lambda m:
            m.group(1)
            + html.escape(value)
            + m.group(3),
        text,
        count=1
    )

    if count != 1:
        raise ValueError(
            name + " 수정 실패"
        )

    return updated


def generate(relative, text, profile):
    kind = old.classify(relative)

    if kind is None:
        raise ValueError(
            "지원하지 않는 페이지 경로"
        )

    if kind in {"home", "region"}:
        return base.generate(
            relative,
            text,
            profile
        )

    info = context(relative, text)

    area = info["area"]
    places = info["places"]
    place_text = "·".join(places)

    section = Path(relative).parts[0]

    category = (
        "출장 마사지"
        if section == "special"
        else "마사지"
    )

    if profile == "A":

        if places:
            ending = (
                f"{place_text} 생활권"
            )

            description = (
                f"{area}의 {place_text} 생활권을 "
                "기준으로 지역정보를 살펴보세요. "
                "가까운 세부 지역을 찾고 연결된 "
                "업체 안내를 확인할 수 있습니다."
            )

            intro = (
                f"{area}에서 {place_text}를 "
                "중심으로 지역을 찾아보세요. "
                "현재 위치와 가까운 생활권부터 "
                "세부 지역정보를 살펴볼 수 있습니다."
            )

        elif kind == "district":
            ending = "동별 지역 안내"

            description = (
                f"{area}의 {category} 정보를 "
                "동별로 확인할 수 있도록 정리했습니다. "
                "현재 위치에 맞는 동을 선택하고 "
                "연결된 지역 안내를 살펴보세요."
            )

            intro = (
                f"{area}의 동별 안내를 "
                "확인해보세요. 현재 위치와 "
                "가까운 동을 선택하면 세부 "
                "지역정보로 이동할 수 있습니다."
            )

        else:
            ending = "주변 지역 살펴보기"

            description = (
                f"{area}의 {category} 관련 "
                "지역정보를 살펴보세요. "
                "현재 위치와 주변 생활권을 "
                "확인하고 연결된 안내로 "
                "이동할 수 있습니다."
            )

            intro = (
                f"{area}에서 가까운 지역을 "
                "찾아보세요. 현재 위치를 기준으로 "
                "주변 생활권을 살펴보고 "
                "연결된 지역정보를 확인할 수 있습니다."
            )

        title = (
            f"{area} {category} | {ending}"
        )

        h1 = (
            f"{area} {category} 지역 안내"
        )

    else:

        title = (
            f"{area} {category} 이용정보 | "
            "코스와 문의 전 확인사항"
        )

        if places:
            region_guide = (
                f"{place_text} 등 희망 지역을 정하고 "
            )
        else:
            region_guide = (
                "희망 위치를 정한 다음 "
            )

        description = (
            f"{area}에서 {category} 이용을 "
            f"준비할 때 참고하세요. {region_guide}"
            "업체별 코스와 문의방법을 "
            "살펴볼 수 있습니다."
        )

        h1 = (
            f"{area} {category} 이용 전 안내"
        )

        intro = (
            f"{area}에서 {category} 이용을 "
            "알아본다면 위치와 희망 시간을 "
            f"먼저 정리해보세요. {region_guide}"
            "연결된 업체의 이용정보를 "
            "확인할 수 있습니다."
        )

    updated = replace_once(
        TITLE_RE,
        text,
        title,
        "TITLE"
    )

    updated = replace_once(
        H1_RE,
        updated,
        h1,
        "H1"
    )

    for key, value in (
        ("description", description),
        ("og:title", title),
        ("og:description", description),
    ):
        updated = base.meta_update(
            updated,
            key,
            value
        )

    updated = replace_p_at(
        updated,
        info["intro_index"],
        intro
    )

    return updated, {
        "type": kind,
        "area": area,
        "title": title,
        "description": description,
        "h1": h1,
        "intro": intro,
    }


def main():
    files = [ROOT / "index.html"]

    for section in ("massage", "special"):
        folder = ROOT / section

        if folder.is_dir():
            files.extend(
                sorted(folder.rglob("index.html"))
            )

    stats = Counter()
    failures = []
    duplicates = {
        ("A", "title"): defaultdict(list),
        ("A", "description"): defaultdict(list),
        ("B", "title"): defaultdict(list),
        ("B", "description"): defaultdict(list),
    }

    examples = []

    for path in files:
        relative = path.relative_to(ROOT).as_posix()

        if old.classify(relative) is None:
            stats["제외"] += 1
            continue

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        stats["검사"] += 1

        try:
            result = {}

            for profile in ("A", "B"):
                updated, info = generate(
                    relative,
                    text,
                    profile
                )

                if updated == text:
                    raise ValueError(
                        profile + " 수정 결과 없음"
                    )

                old_links = re.findall(
                    r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
                    text,
                    re.I | re.S
                )

                new_links = re.findall(
                    r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
                    updated,
                    re.I | re.S
                )

                if old_links != new_links:
                    raise ValueError(
                        profile + " 링크 변경"
                    )

                result[profile] = info

                for field in (
                    "title",
                    "description"
                ):
                    duplicates[
                        (profile, field)
                    ][info[field]].append(relative)

            stats["성공"] += 1

            if len(examples) < 8:
                examples.append(
                    (
                        relative,
                        result["A"]["title"],
                        result["B"]["title"]
                    )
                )

        except Exception as exc:
            stats["실패"] += 1

            if len(failures) < 25:
                failures.append(
                    (relative, str(exc))
                )

    print("=" * 70)
    print("V3 보완판 전체 지역 검사")
    print("=" * 70)

    print("검사:", stats["검사"])
    print("성공:", stats["성공"])
    print("실패:", stats["실패"])
    print("경로 제외:", stats["제외"])

    print()
    print("제목·설명 중복 검사")

    for (profile, field), groups in duplicates.items():
        repeated = [
            (value, paths)
            for value, paths in groups.items()
            if len(paths) > 1
        ]

        count = sum(
            len(paths) - 1
            for _, paths in repeated
        )

        print(
            profile,
            field.upper(),
            "중복:",
            count
        )

        for value, paths in repeated[:2]:
            print(" 문구:", value[:130])

            for path in paths[:4]:
                print("  -", path)

    print()
    print("실패 사례")

    for relative, reason in failures:
        print(relative, "=>", reason)

    print()
    print("A/B 제목 샘플")

    for relative, a, b in examples:
        print()
        print(relative)
        print("A:", a)
        print("B:", b)

    print()
    print("검사 완료")
    print("홈페이지 HTML 수정 없음")
    print("기존 V2·V3 제작기 수정 없음")


if __name__ == "__main__":
    main()
