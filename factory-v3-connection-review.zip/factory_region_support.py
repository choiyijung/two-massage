import re
import html
import shutil
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import urlparse, unquote, urljoin


REGION_DIRECT = {

    "seoul": {
        "gangnam-gu","gangdong-gu","gangbuk-gu","gangseo-gu",
        "gwanak-gu","gwangjin-gu","guro-gu","geumcheon-gu",
        "nowon-gu","dobong-gu","dongdaemun-gu","dongjak-gu",
        "mapo-gu","seodaemun-gu","seocho-gu","seongdong-gu",
        "seongbuk-gu","songpa-gu","yangcheon-gu","yeongdeungpo-gu",
        "yongsan-gu","eunpyeong-gu","jongno-gu","jung-gu","jungnang-gu",
        "seoul"
    },

    "gyeonggi": {
        "ansan","anseong","anyang","bucheon","dongducheon",
        "gapyeong","gimpo","goyang","gunpo","guri",
        "gwacheon","gwangju-gyeonggi","gwangmyeong","hanam",
        "hwaseong","icheon","namyangju","osan","paju","pocheon",
        "pyeongtaek","seongnam","siheung","suwon","uijeongbu",
        "uiwang","yangju","yangpyeong","yeoju","yeoncheon",
        "yongin","gyeonggi"
    },

    "incheon": {
        "bupyeong-gu","ganghwa-gun","geomdan-gu","gyeyang-gu",
        "jemulpo-gu","michuhol-gu","namdong-gu","ongjin-gun",
        "seohae-gu","yeongjong-gu","yeonsu-gu",
        "incheon"
    },

    "other": {
        "asan","changwon","cheonan","cheongju",
        "daegu","daejeon","gimhae","gongju",
        "gunsan","gwangju","gyeryong","iksan",
        "jeonju","sejong"
    }
}


def enabled_regions(cfg):

    setting = cfg.get(
        "regions",
        {}
    )

    result = {}

    for region in (
        "seoul",
        "gyeonggi",
        "incheon",
        "other"
    ):
        result[region] = bool(
            setting.get(region, True)
        )

    return result


def disabled_regions(cfg):

    state = enabled_regions(cfg)

    return {
        k
        for k,v in state.items()
        if not v
    }


def count_html(root):

    if not root.exists():
        return 0

    return sum(
        1 for _ in root.rglob("*.html")
    )


def remove_regions(target, cfg):

    disabled = disabled_regions(cfg)

    stats = {
        "disabled": sorted(disabled),
        "removed_dirs": 0,
        "removed_html": 0,
    }

    for region in disabled:

        # ----------------------------
        # 직접 지역 루트
        # ----------------------------

        for folder in REGION_DIRECT[region]:

            p = target / folder

            if not p.exists():
                continue

            stats["removed_html"] += count_html(p)

            shutil.rmtree(p)

            stats["removed_dirs"] += 1

        # ----------------------------
        # /massage/지역
        # ----------------------------

        p = target / "massage" / region

        if p.exists():

            stats["removed_html"] += count_html(p)

            shutil.rmtree(p)

            stats["removed_dirs"] += 1

        # ----------------------------
        # /special/지역
        # other는 원본에 없어도 안전
        # ----------------------------

        p = target / "special" / region

        if p.exists():

            stats["removed_html"] += count_html(p)

            shutil.rmtree(p)

            stats["removed_dirs"] += 1

    return stats


def path_region(path):

    path = unquote(
        path or ""
    )

    path = "/" + path.lstrip("/")

    parts = [
        x for x in path.split("/")
        if x
    ]

    if not parts:
        return None

    # /massage/seoul/...
    # /special/seoul/...

    if (
        len(parts) >= 2
        and parts[0] in {"massage","special"}
        and parts[1] in {
            "seoul","gyeonggi",
            "incheon","other"
        }
    ):
        return parts[1]

    first = parts[0]

    for region, folders in REGION_DIRECT.items():

        if first in folders:
            return region

    return None


def filter_sitemap(target, cfg):

    sitemap = target / "sitemap.xml"

    result = {
        "before": 0,
        "removed": 0,
        "after": 0
    }

    if not sitemap.exists():
        return result

    disabled = disabled_regions(cfg)

    tree = ET.parse(sitemap)
    root = tree.getroot()

    if root.tag.startswith("{"):

        namespace = root.tag.split("}")[0][1:]

        ET.register_namespace(
            "",
            namespace
        )

        url_tag = f"{{{namespace}}}url"
        loc_tag = f"{{{namespace}}}loc"

    else:

        url_tag = "url"
        loc_tag = "loc"

    urls = list(
        root.findall(url_tag)
    )

    result["before"] = len(urls)

    for url_el in urls:

        loc_el = url_el.find(
            loc_tag
        )

        if (
            loc_el is None
            or not loc_el.text
        ):
            continue

        parsed = urlparse(
            html.unescape(
                loc_el.text.strip()
            )
        )

        region = path_region(
            parsed.path
        )

        if region in disabled:

            root.remove(
                url_el
            )

            result["removed"] += 1

    tree.write(
        sitemap,
        encoding="utf-8",
        xml_declaration=True
    )

    result["after"] = (
        result["before"]
        - result["removed"]
    )

    return result


def get_canonical(text):

    m = re.search(
        r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\'](.*?)["\']',
        text,
        re.I | re.S
    )

    return (
        html.unescape(
            m.group(1)
        ).strip()
        if m else ""
    )


def scan_disabled_links(
    target,
    cfg
):

    disabled = disabled_regions(cfg)

    samples = []
    count = 0

    for p in target.rglob("*.html"):

        text = p.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        base = get_canonical(
            text
        )

        if not base:
            continue

        hrefs = re.findall(
            r'<a\b[^>]+href=["\']([^"\']+)["\']',
            text,
            re.I
        )

        for href in hrefs:

            href = html.unescape(
                href.strip()
            )

            lower = href.lower()

            if (
                not href
                or href.startswith("#")
                or lower.startswith("tel:")
                or lower.startswith("mailto:")
                or lower.startswith("javascript:")
                or lower.startswith("data:")
            ):
                continue

            full = urljoin(
                base,
                href
            )

            parsed = urlparse(
                full
            )

            region = path_region(
                parsed.path
            )

            if region in disabled:

                count += 1

                if len(samples) < 30:
                    samples.append(
                        (
                            str(
                                p.relative_to(target)
                            ),
                            href,
                            region
                        )
                    )

    return {
        "count": count,
        "samples": samples
    }


def remove_disabled_region_links(
    target,
    cfg
):
    import re
    import html
    from urllib.parse import urljoin, urlparse

    disabled = disabled_regions(cfg)

    result = {
        "changed_files": 0,
        "removed_links": 0
    }

    for p in target.rglob("*.html"):

        text = p.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        base = get_canonical(text)

        if not base:
            continue

        original = text

        pattern = re.compile(
            r'<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>.*?</a>',
            re.I | re.S
        )

        def repl(match):

            href = html.unescape(
                match.group(1).strip()
            )

            lower = href.lower()

            if (
                not href
                or href.startswith("#")
                or lower.startswith("tel:")
                or lower.startswith("mailto:")
                or lower.startswith("javascript:")
                or lower.startswith("data:")
            ):
                return match.group(0)

            full = urljoin(
                base,
                href
            )

            parsed = urlparse(
                full
            )

            region = path_region(
                parsed.path
            )

            if region in disabled:

                result["removed_links"] += 1
                return ""

            return match.group(0)

        text = pattern.sub(
            repl,
            text
        )

        # 비어버린 단순 li 정리
        text = re.sub(
            r'<li\b[^>]*>\s*</li>',
            '',
            text,
            flags=re.I | re.S
        )

        if text != original:

            p.write_text(
                text,
                encoding="utf-8"
            )

            result["changed_files"] += 1

    return result
