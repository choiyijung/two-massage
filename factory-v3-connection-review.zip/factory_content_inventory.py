﻿import re
import html
from pathlib import Path

ROOT = Path(r"E:\massage-auto-test")

GROUPS = {
    "서울": ROOT / "gangnam-gu" / "개포동" / "shops",
    "경기": ROOT / "ansan",
    "인천": ROOT / "bupyeong-gu",
    "기타": ROOT / "asan",
}

def extract(pattern, text):
    m = re.search(pattern, text, re.I | re.S)

    if not m:
        return ""

    value = re.sub(r"<[^>]+>", "", m.group(1))
    return html.unescape(value).strip()

print("=" * 75)
print("자동 고유본문 생성 전 HTML 구조 확인")
print("=" * 75)

for region, folder in GROUPS.items():

    print()
    print("===== " + region + " =====")

    if not folder.exists():
        print("폴더 없음:", folder)
        continue

    files = sorted(
        p for p in folder.rglob("index.html")
        if "shops" in p.parts
    )

    print("상세페이지:", len(files))

    for p in files[:3]:

        text = p.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        title = extract(
            r"<title[^>]*>(.*?)</title>",
            text
        )

        desc = extract(
            r'<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']',
            text
        )

        h1 = extract(
            r"<h1[^>]*>(.*?)</h1>",
            text
        )

        intro = extract(
            r'<h2>\s*업체소개\s*</h2>\s*'
            r'<p[^>]*class=["\']ml-copy["\'][^>]*>(.*?)</p>',
            text
        )

        print()
        print("파일:", p.relative_to(ROOT))
        print("TITLE:", title)
        print("DESCRIPTION:", desc[:180])
        print("H1:", h1)
        print("업체소개 글자수:", len(intro))
        print("업체소개 샘플:", intro[:150])

print()
print("구조 확인 완료")
