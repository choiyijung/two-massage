import re
import html
import hashlib
from pathlib import Path
from collections import Counter

TITLE_RE = re.compile(
    r'(<title\b[^>]*>)(.*?)(</title>)',
    re.I | re.S
)

INTRO_RE = re.compile(
    r'(<h2\b[^>]*>\s*업체소개\s*</h2>\s*'
    r'<p\b[^>]*class=["\'][^"\']*\bml-copy\b[^"\']*["\'][^>]*>)'
    r'(.*?)'
    r'(</p>)',
    re.I | re.S
)

SHORT_RE = re.compile(
    r'(<p\b[^>]*class=["\'][^"\']*\bml-test-intro\b[^"\']*["\'][^>]*>)'
    r'(.*?)'
    r'(</p>)',
    re.I | re.S
)

H1_RE = re.compile(
    r'<h1\b[^>]*class=["\'][^"\']*\bml-test-title\b[^"\']*["\'][^>]*>'
    r'(.*?)</h1>',
    re.I | re.S
)

META_RE = re.compile(
    r'<meta\b[^>]*>',
    re.I | re.S
)

CONTENT_RE = re.compile(
    r'(\bcontent\s*=\s*)(["\'])(.*?)\2',
    re.I | re.S
)

OPENINGS = [
    [
        "{area}에서 {shop} 관련 {topic} 마사지 정보를 확인할 때는 이용시간과 코스 구성을 먼저 살펴보는 것이 편리합니다.",
        "{area} 생활권에서 {shop} 이용을 알아본다면 {topic} 마사지 코스와 예약 안내를 함께 비교해보세요."
    ],
    [
        "{area}에서 {shop} 코스를 알아보는 분들을 위해 {topic} 마사지 이용정보를 정리했습니다.",
        "{area} 지역의 {shop} 안내에서는 {topic} 마사지 코스와 이용 전에 확인할 사항을 살펴볼 수 있습니다."
    ],
    [
        "{area}에서 {shop} 이용을 처음 알아본다면 예약 절차와 {topic} 마사지 코스부터 확인해보세요.",
        "{area} 생활권에서 {shop} 관련 정보를 찾는 분들이 {topic} 마사지 이용 흐름을 살펴볼 수 있도록 구성했습니다."
    ],
    [
        "{area}에서 {shop} 방문 일정을 계획할 때 참고할 수 있는 {topic} 마사지 이용안내입니다.",
        "{area} 지역에서 {shop} 이용을 준비한다면 {topic} 마사지 코스와 방문 전 확인사항을 함께 살펴보세요."
    ],
    [
        "{area}의 {shop} 관련 코스와 예약 정보를 확인할 수 있도록 기본적인 {topic} 마사지 이용사항을 정리했습니다.",
        "{area}에서 {shop} 이용을 검토하는 분들을 위해 {topic} 마사지 코스와 문의 전 참고사항을 안내합니다."
    ]
]

SENTENCES = [
    [
        "페이지에 표시된 코스별 시간을 비교하면 원하는 일정에 맞는 구성을 살펴볼 수 있습니다.",
        "코스표에서 이용시간을 확인한 뒤 필요한 구성을 비교하는 방식으로 선택할 수 있습니다.",
        "이용시간별 코스 안내를 참고하면 당일 일정에 맞춰 내용을 확인하기 편합니다.",
        "여러 코스가 안내되어 있다면 시간과 구성을 차례대로 살펴보는 것이 좋습니다."
    ],
    [
        "예약 문의 전에는 희망 시간과 이용할 지역을 미리 정리해두면 좋습니다.",
        "문의할 때 원하는 일정과 이용 위치를 함께 전달하면 확인 과정이 수월합니다.",
        "예약 상담에서는 희망 날짜와 시간대를 함께 알려주는 것이 도움이 됩니다.",
        "이용을 계획하고 있다면 방문 위치와 가능한 시간을 먼저 확인해보세요."
    ],
    [
        "처음 이용하는 경우에는 코스별 차이와 예약 순서를 상담 과정에서 확인할 수 있습니다.",
        "이용 절차가 궁금하다면 코스 선택과 예약 방법을 함께 문의해보세요.",
        "첫 문의에서는 원하는 코스와 이용시간을 전달하고 필요한 안내를 확인하면 됩니다.",
        "예약이 익숙하지 않다면 이용 방법과 일정에 대한 궁금한 내용을 미리 확인하는 편이 좋습니다."
    ],
    [
        "실제 이용 가능 시간은 당일 예약 상황에 따라 달라질 수 있으므로 최종 확인이 필요합니다.",
        "희망 시간이 있더라도 기존 일정에 따라 조정될 수 있어 상담 후 확정 내용을 확인해야 합니다.",
        "방문 일정은 예약 현황과 이동 상황에 영향을 받을 수 있으므로 안내받은 시간을 기준으로 확인해주세요.",
        "표시된 운영정보와 실제 가능한 시간에 차이가 있을 수 있어 이용 전 최종 일정을 확인하는 것이 좋습니다."
    ],
    [
        "방문 전에는 이용 장소와 예약 시간을 다시 살펴보면 준비가 한결 간단해집니다.",
        "일정이 확정되면 이용할 공간과 시간을 한 번 더 확인해두는 것이 좋습니다.",
        "당일 준비를 위해 필요한 내용을 예약 단계에서 미리 확인해두면 편리합니다.",
        "방문 장소와 시간을 사전에 정리해두면 이용 준비를 보다 수월하게 진행할 수 있습니다."
    ],
    [
        "페이지의 업체정보와 이용안내를 함께 살펴보면 기본적인 내용을 확인할 수 있습니다.",
        "운영정보와 코스표를 같이 확인하면 예약 전에 필요한 내용을 파악하기 편합니다.",
        "이용 관련 안내는 페이지에 표시된 내용과 상담에서 확인한 최종 정보를 함께 참고해주세요.",
        "코스와 운영 안내를 순서대로 확인하면 이용 전에 살펴볼 항목을 정리하기 좋습니다."
    ],
    [
        "{area}에서 일정을 계획한다면 코스와 예약 가능 여부를 차례대로 확인해보세요.",
        "{area} 이용 전에는 원하는 시간과 코스정보를 함께 살펴보는 것이 좋습니다.",
        "{area}에서 방문을 준비한다면 이용시간과 최종 예약 내용을 확인해주세요.",
        "{area} 생활권에서 이용을 알아볼 때는 페이지 안내와 실제 가능한 일정을 함께 확인해보세요."
    ]
]

TITLE_ENDINGS = [
    "코스·예약 이용안내",
    "이용시간과 문의방법",
    "프로그램 및 예약정보",
    "코스 구성과 이용절차",
    "예약 전 확인사항",
    "이용방법과 코스 안내"
]

DESCRIPTION_ENDINGS = [
    "코스표와 이용시간을 살펴보고 예약 전에 필요한 정보를 확인해보세요.",
    "이용 가능한 일정과 코스별 내용을 확인하고 예약 방법을 살펴보세요.",
    "코스 구성과 문의 절차를 확인하고 방문 전 참고할 내용을 살펴보세요.",
    "이용시간과 운영 안내를 함께 확인하고 필요한 내용을 문의해보세요."
]

def choose(options, key):
    digest = hashlib.sha256(
        key.encode("utf-8")
    ).hexdigest()

    number = int(digest[:16], 16)

    return options[number % len(options)]

def clean(value):
    value = re.sub(
        r'<[^>]+>',
        '',
        value
    )

    return html.unescape(value).strip()

def replace_meta(text, meta_name, value):

    changed = 0

    def replace_tag(match):
        nonlocal changed

        tag = match.group(0)

        name_pattern = (
            r'\b(?:name|property)\s*=\s*'
            r'(["\'])'
            + re.escape(meta_name)
            + r'\1'
        )

        if not re.search(
            name_pattern,
            tag,
            re.I
        ):
            return tag

        def replace_content(m):
            return (
                m.group(1)
                + m.group(2)
                + html.escape(
                    value,
                    quote=True
                )
                + m.group(2)
            )

        result, count = CONTENT_RE.subn(
            replace_content,
            tag,
            count=1
        )

        changed += count

        return result

    new_text = META_RE.sub(
        replace_tag,
        text
    )

    return new_text, changed

def generate_content(root, seed):

    root = Path(root).resolve()

    forbidden = {
        Path(r"E:\massage-auto-test").resolve(),
        Path(r"E:\seoul-massage-rebuild").resolve()
    }

    if root in forbidden:
        raise RuntimeError(
            "마스터 또는 기존 운영 사이트는 수정할 수 없습니다."
        )

    if not root.exists():
        raise RuntimeError(
            "생성 대상 폴더가 없습니다."
        )

    files = sorted(
        p for p in root.rglob("index.html")
        if "shops" in p.parts
        and p.parent.name in {"001", "002", "003", "004", "005"}
        and p.parent.parent.name == "shops"
    )

    stats = Counter()
    samples = []

    for path in files:

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        title_match = TITLE_RE.search(text)
        intro_match = INTRO_RE.search(text)
        h1_match = H1_RE.search(text)

        if not all([
            title_match,
            intro_match,
            h1_match
        ]):
            stats["structure_skipped"] += 1
            continue

        old_title = clean(
            title_match.group(2)
        )

        shop = clean(
            h1_match.group(1)
        )

        topic_match = re.match(
            r'^(.*?)\s+출장\s+(.+?)\s+마사지\b',
            old_title
        )

        topic = (
            topic_match.group(2).strip()
            if topic_match
            else ""
        )

        area = (
            topic_match.group(1).strip()
            if topic_match
            else old_title.split("|")[0].replace(shop, "").strip()
        )

        # 서울 25구는 실제 폴더명에서 지역명을 결정
        SEOUL_NAMES = {
            "gangnam-gu": "강남구",
            "gangdong-gu": "강동구",
            "gangbuk-gu": "강북구",
            "gangseo-gu": "강서구",
            "gwanak-gu": "관악구",
            "gwangjin-gu": "광진구",
            "guro-gu": "구로구",
            "geumcheon-gu": "금천구",
            "nowon-gu": "노원구",
            "dobong-gu": "도봉구",
            "dongdaemun-gu": "동대문구",
            "dongjak-gu": "동작구",
            "mapo-gu": "마포구",
            "seodaemun-gu": "서대문구",
            "seocho-gu": "서초구",
            "seongdong-gu": "성동구",
            "seongbuk-gu": "성북구",
            "songpa-gu": "송파구",
            "yangcheon-gu": "양천구",
            "yeongdeungpo-gu": "영등포구",
            "yongsan-gu": "용산구",
            "eunpyeong-gu": "은평구",
            "jongno-gu": "종로구",
            "jung-gu": "중구",
            "jungnang-gu": "중랑구",
        }

        path_parts = path.relative_to(root).parts

        if path_parts[0] in SEOUL_NAMES:
            gu_name = SEOUL_NAMES[path_parts[0]]

            if path_parts[1] == "shops":
                area = gu_name
            else:
                dong_name = path_parts[1]

                if old_title.startswith("서울 "):
                    area = f"서울 {gu_name} {dong_name}"
                else:
                    area = f"{gu_name} {dong_name}"

        rel = path.relative_to(root).as_posix()

        key = (
            seed
            + "|"
            + rel
            + "|"
            + shop
        )

        profile = int(
            hashlib.sha256(
                (key + "|profile").encode("utf-8")
            ).hexdigest()[:8],
            16
        ) % len(OPENINGS)

        opening = choose(
            OPENINGS[profile],
            key + "|opening"
        ).format(
            area=area,
            shop=shop,
            topic=topic
        )

        # 기존 제목에 서비스 유형이 없는 페이지
        if not topic:
            opening = (
                f"{area}에서 {shop} 이용을 알아본다면 "
                f"페이지에 안내된 코스와 이용시간을 먼저 "
                f"확인해보세요."
            )

        sentences = []

        for i, pool in enumerate(SENTENCES):

            sentence = choose(
                pool,
                key + "|sentence|" + str(i)
            ).format(
                area=area,
                shop=shop,
                topic=topic
            )

            sentences.append(sentence)

        new_intro = " ".join(
            [opening] + sentences
        )

        ending = choose(
            TITLE_ENDINGS,
            key + "|title"
        )

        if topic:
            new_title = (
                f"{area} 출장 {topic} 마사지"
                f" | {shop} {ending}"
            )
        else:
            new_title = (
                f"{area} {shop}"
                f" | {ending}"
            )

        description_ending = choose(
            DESCRIPTION_ENDINGS,
            key + "|description"
        )

        if topic:
            new_description = (
                f"{area} {shop} 출장 {topic} 마사지 "
                f"이용정보를 안내합니다. "
                f"{description_ending}"
            )
        else:
            new_description = (
                f"{area} {shop} 코스와 예약 관련 "
                f"이용정보를 안내합니다. "
                f"{description_ending}"
            )

        # DESCRIPTION 구조가 확인되는 경우만 수정
        check_text, desc_count = replace_meta(
            text,
            "description",
            new_description
        )

        if desc_count != 1:
            stats["description_skipped"] += 1
            continue

        new_text = check_text

        new_text = TITLE_RE.sub(
            lambda m:
                m.group(1)
                + html.escape(new_title)
                + m.group(3),
            new_text,
            count=1
        )

        new_text = INTRO_RE.sub(
            lambda m:
                m.group(1)
                + html.escape(new_intro)
                + m.group(3),
            new_text,
            count=1
        )

        short = (
            f"{area} {shop} "
            f"코스와 예약 이용안내"
        )

        new_text = SHORT_RE.sub(
            lambda m:
                m.group(1)
                + html.escape(short)
                + m.group(3),
            new_text,
            count=1
        )

        # 기존에 존재하는 SNS 메타도 동기화
        for name, value in [
            ("og:title", new_title),
            ("og:description", new_description),
            ("twitter:title", new_title),
            ("twitter:description", new_description)
        ]:

            new_text, _ = replace_meta(
                new_text,
                name,
                value
            )

        path.write_text(
            new_text,
            encoding="utf-8"
        )

        stats["changed"] += 1

        if len(samples) < 5:
            samples.append({
                "file": rel,
                "title": new_title,
                "description": new_description,
                "intro_length": len(new_intro)
            })

    print("=" * 75)
    print("새 홈페이지 TITLE·DESCRIPTION·업체소개 자동생성")
    print("=" * 75)

    print("검사 상세페이지 :", len(files))
    print("수정 페이지     :", stats["changed"])
    print("구조 제외       :", stats["structure_skipped"])
    print("제목형식 제외   :", stats["title_pattern_skipped"])
    print("설명형식 제외   :", stats["description_skipped"])

    print()
    print("===== 생성 샘플 =====")

    for row in samples:
        print()
        print("파일:", row["file"])
        print("TITLE:", row["title"])
        print("DESCRIPTION:", row["description"])
        print("업체소개 길이:", row["intro_length"])

    return dict(stats)
