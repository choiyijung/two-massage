﻿import os
import shutil
from pathlib import Path

BASE = Path(r"D:\massage-sites")

LAYOUT_A = r"""

/* ===== FACTORY V3 LAYOUT A START ===== */

/* 지역 탐색형 메인: 검색과 지역 목록을 앞쪽에 배치 */
main:has(> .main-title-section) {
    display: flex !important;
    flex-direction: column !important;
    align-items: stretch;
}

main > .main-title-section { order: -10; }
main > .search-area { order: -9; }
main > .region-guide { order: -8; }
main > .categories-section { order: -7; }
main > .quick { order: -6; }
main > .main-special { order: -5; }

main > .main-title-section {
    border-bottom: 3px solid #1D4ED8;
    padding-bottom: 22px !important;
}

main > .search-area {
    width: min(100%, 1000px);
    margin: 22px auto 30px !important;
    padding: 18px !important;
    background: #EFF6FF !important;
    border: 1px solid #BFDBFE;
    border-radius: 16px;
    box-sizing: border-box;
}

main > .region-guide {
    background: #EFF6FF !important;
    border: 1px solid #BFDBFE;
    border-radius: 20px;
    padding: 24px !important;
}

main > .region-guide .region-boxes {
    display: grid !important;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
}

/* 지역페이지: 단정한 지역 안내형 */
.article-main .article-hero.entity-hero {
    border-left: 6px solid #1D4ED8 !important;
    border-radius: 8px 18px 18px 8px !important;
    padding: 28px !important;
    text-align: left !important;
}

.article-main .jt-region-poster {
    border-radius: 18px !important;
    overflow: hidden;
}

/* 업체페이지: 세로형 소개 카드 */
.ml-test-detail .ml-test-hero {
    display: block !important;
    border-top: 6px solid #1D4ED8 !important;
    border-radius: 18px !important;
    overflow: hidden;
}

.ml-test-detail .ml-test-hero-top {
    padding-bottom: 14px;
}

.ml-test-detail #course {
    border-left: 4px solid #1D4ED8;
    border-radius: 12px;
}

@media (max-width: 767px) {
    main > .region-guide .region-boxes {
        grid-template-columns: 1fr !important;
    }

    main > .search-area {
        padding: 12px !important;
    }

    .article-main .article-hero.entity-hero {
        padding: 19px !important;
    }
}

/* ===== FACTORY V3 LAYOUT A END ===== */
"""

LAYOUT_B = r"""

/* ===== FACTORY V3 LAYOUT B START ===== */

/* 코스 안내형 메인: 카테고리와 추천 영역을 먼저 노출 */
main:has(> .main-title-section) {
    display: flex !important;
    flex-direction: column !important;
    align-items: stretch;
}

main > .main-title-section { order: -10; }
main > .categories-section { order: -9; }
main > .quick { order: -8; }
main > .main-special { order: -7; }
main > .search-area { order: -6; }
main > .region-guide { order: -5; }

main > .main-title-section {
    background: linear-gradient(
        135deg,
        #9A3412,
        #C2410C
    ) !important;
    color: white !important;
    border-radius: 22px;
    margin-top: 20px;
    padding: 36px 22px !important;
}

main > .main-title-section h1 {
    color: white !important;
}

main > .categories-section {
    background: #FFF7ED !important;
    border: 1px solid #FED7AA;
    border-radius: 22px;
    padding: 24px !important;
    margin-top: 22px !important;
}

main > .categories-section .card {
    border-radius: 17px !important;
    overflow: hidden;
    box-shadow: 0 8px 22px rgba(124,45,18,.10);
}

main > .search-area {
    width: min(100%, 850px);
    margin: 26px auto !important;
    box-sizing: border-box;
}

main > .region-guide {
    border-top: 4px solid #FB923C;
    margin-top: 24px !important;
}

/* 지역페이지: 제목과 이용 설명을 나란히 배치 */
.article-main .article-hero.entity-hero {
    display: grid !important;
    grid-template-columns: minmax(0, 1.1fr) minmax(0, .9fr);
    gap: 12px 28px;
    align-items: center;
    background: linear-gradient(
        135deg,
        #FFF7ED,
        #FFEDD5
    ) !important;
    border: 1px solid #FED7AA;
    border-radius: 24px !important;
    padding: 30px !important;
    text-align: left !important;
}

.article-main .article-hero.entity-hero > small {
    grid-column: 1 / -1;
}

.article-main .article-hero.entity-hero > h1 {
    grid-column: 1;
}

.article-main .article-hero.entity-hero > p {
    grid-column: 2;
}

.article-main .jt-region-poster {
    border-radius: 28px !important;
    overflow: hidden;
}

/* 업체페이지: PC 2열 소개형 */
.ml-test-detail .ml-test-hero {
    display: grid !important;
    grid-template-columns: minmax(0, 1.2fr) minmax(0, .8fr);
    gap: 14px 20px;
    align-items: stretch;
    padding: 24px !important;
    background: #FFF7ED !important;
    border: 1px solid #FED7AA;
    border-radius: 24px !important;
}

.ml-test-detail .ml-test-hero-top {
    grid-column: 1;
    grid-row: 1 / span 2;
}

.ml-test-detail .ml-test-feature {
    grid-column: 2;
    grid-row: 1;
}

.ml-test-detail .ml-test-hero-bottom {
    grid-column: 2;
    grid-row: 2;
}

.ml-test-detail #course {
    border-top: 5px solid #FB923C;
    border-radius: 18px;
}

@media (max-width: 767px) {
    .article-main .article-hero.entity-hero,
    .ml-test-detail .ml-test-hero {
        display: block !important;
        padding: 18px !important;
    }

    main > .categories-section {
        padding: 14px !important;
    }

    main > .main-title-section {
        padding: 26px 16px !important;
    }
}

/* ===== FACTORY V3 LAYOUT B END ===== */
"""


def apply_layout(target, profile):
    target = Path(target).resolve()

    if target.parent != BASE.resolve():
        raise RuntimeError(
            "D:\\massage-sites 바로 아래의 사이트만 수정합니다."
        )

    if profile not in ("A", "B"):
        raise RuntimeError("레이아웃 유형은 A 또는 B만 가능합니다.")

    css = target / "assets/css/style.css"
    backup = css.with_name("style.css.before-v3-layout")

    if not css.is_file():
        raise RuntimeError(f"CSS 파일 없음: {css}")

    if backup.exists():
        raise RuntimeError(
            f"기존 레이아웃 백업이 있습니다: {backup}"
        )

    home = target / "index.html"
    region = target / "massage/seoul/index.html"
    shop = target / "asan/shops/001/index.html"

    required = [
        (home, "main-title-section"),
        (home, "search-area"),
        (home, "categories-section"),
        (home, "region-guide"),
        (region, "article-hero"),
        (shop, "ml-test-hero"),
    ]

    for path, marker in required:
        if not path.is_file():
            raise RuntimeError(f"구조 확인 파일 없음: {path}")

        if marker not in path.read_text(
            encoding="utf-8",
            errors="ignore"
        ):
            raise RuntimeError(
                f"레이아웃 적용 전 구조 확인 필요: {path}"
            )

    original = css.read_text(
        encoding="utf-8",
        errors="strict"
    )

    if "FACTORY V3 LAYOUT" in original:
        raise RuntimeError(
            f"이미 V3 레이아웃이 포함돼 있습니다: {css}"
        )

    addition = LAYOUT_A if profile == "A" else LAYOUT_B
    changed = original + "\n" + addition

    shutil.copy2(css, backup)

    temp = css.with_name("style.css.v3-writing")

    try:
        temp.write_text(
            changed,
            encoding="utf-8"
        )

        os.replace(temp, css)

    except Exception:
        if temp.exists():
            temp.unlink()

        shutil.copy2(backup, css)
        raise

    print()
    print(profile, "레이아웃 적용 완료")
    print("CSS:", css)
    print("백업:", backup)
    print("추가 CSS 문자:", len(addition))


if __name__ == "__main__":

    sites = [
        (BASE / "massage-v3-A", "A"),
        (BASE / "massage-v3-B", "B"),
    ]

    # 두 사이트 모두 안전검사 후 변경 시작
    for target, profile in sites:

        css = target / "assets/css/style.css"
        backup = css.with_name("style.css.before-v3-layout")

        if not css.is_file():
            raise RuntimeError(f"CSS 없음: {css}")

        if backup.exists():
            raise RuntimeError(
                f"기존 백업이 있습니다: {backup}"
            )

        if "FACTORY V3 LAYOUT" in css.read_text(
            encoding="utf-8",
            errors="ignore"
        ):
            raise RuntimeError(
                f"이미 적용된 사이트입니다: {target}"
            )

    for target, profile in sites:
        apply_layout(target, profile)

    print()
    print("=" * 60)
    print("A/B 실제 레이아웃 변경 완료")
    print("HTML 변경 없음")
    print("전화·문자·코스·가격·링크 변경 없음")
    print("V2 및 운영 사이트 변경 없음")
