﻿import re
from pathlib import Path
from collections import Counter

ROOT = Path(r"E:\massage-auto-test")

print("=" * 80)
print("자동제작 마스터 구조 조사")
print("=" * 80)

# 메인 title
main = ROOT / "index.html"

if main.exists():
    s = main.read_text(encoding="utf-8", errors="ignore")

    m = re.search(
        r"<title[^>]*>(.*?)</title>",
        s,
        re.I | re.S
    )

    print(
        "메인 TITLE:",
        re.sub(r"<[^>]+>", "", m.group(1)).strip()
        if m else "없음"
    )

# CSS
css_files = sorted(ROOT.rglob("*.css"))

print()
print("CSS 파일:", len(css_files))

for p in css_files[:30]:
    try:
        print(" -", p.relative_to(ROOT))
    except:
        pass

# 컬러 빈도
colors = Counter()

for p in css_files:
    text = p.read_text(
        encoding="utf-8",
        errors="ignore"
    )

    for c in re.findall(
        r'#[0-9a-fA-F]{6}\b',
        text
    ):
        colors[c.upper()] += 1

print()
print("===== 많이 쓰는 색상 =====")

for color,count in colors.most_common(20):
    print(color, ":", count)

# 이미지
image_ext = {
    ".jpg",".jpeg",".png",
    ".webp",".gif",".svg",".ico"
}

images = [
    p for p in ROOT.rglob("*")
    if p.is_file()
    and p.suffix.lower() in image_ext
    and "_backup" not in str(p).lower()
    and "_auto_backup" not in str(p).lower()
]

print()
print("이미지 파일:", len(images))

print()
print("===== 이미지 샘플 =====")

for p in images[:40]:
    print(" -", p.relative_to(ROOT))

# HTML에서 많이 참조되는 이미지
refs = Counter()

for p in ROOT.rglob("*.html"):

    if "_backup" in str(p).lower():
        continue

    text = p.read_text(
        encoding="utf-8",
        errors="ignore"
    )

    for x in re.findall(
        r'(?:src|content)=["\']([^"\']+\.(?:jpg|jpeg|png|webp|gif|svg))',
        text,
        re.I
    ):
        refs[x] += 1

print()
print("===== HTML에서 많이 쓰는 이미지 =====")

for x,count in refs.most_common(20):
    print(count, ":", x)

print()
print("조사 완료")
