import argparse
import json
import re
from pathlib import Path
from urllib.parse import quote

import build_site_from_config as base

from factory_region_support import (
    enabled_regions,
    remove_regions,
    filter_sitemap,
    scan_disabled_links,
    remove_disabled_region_links,
)


from factory_public_urls import materialize_shop_urls
from factory_canonical_redirects import build_canonical_redirects
from factory_sitemap_shop_urls import sync_indexable_shop_urls
from factory_content_generator import generate_content


MASTER = Path(r"E:\massage-auto-test")


def load_config(path):

    return json.loads(
        Path(path).read_text(
            encoding="utf-8-sig"
        )
    )


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--config",
        default=str(
            MASTER / "factory_config.json"
        )
    )

    parser.add_argument(
        "--validate-only",
        action="store_true"
    )

    args = parser.parse_args()

    cfg = load_config(
        args.config
    )

    errors, warnings = (
        base.validate_config(cfg)
    )

    print("=" * 78)
    print("마사지 자동제작기 V2")
    print("=" * 78)

    print(
        "CONFIG :",
        args.config
    )

    print(
        "TARGET :",
        cfg.get("target","")
    )

    print(
        "DOMAIN :",
        cfg.get("domain","")
        or "(기존 유지)"
    )

    print()
    print("지역 선택:")

    states = enabled_regions(
        cfg
    )

    for region,state in states.items():
        print(
            f"  {region:10} :",
            "사용"
            if state
            else "제외"
        )

    if warnings:

        print()

        for x in warnings:
            print(
                "주의:",
                x
            )

    if errors:

        print()

        for x in errors:
            print(
                "오류:",
                x
            )

        raise SystemExit(
            "\nCONFIG 오류"
        )

    if args.validate_only:

        print()
        print("CONFIG 구조: 정상")
        return

    target = Path(
        cfg["target"]
    )

    # --------------------------------
    # 1. 복제
    # --------------------------------

    print()
    print("===== 1. 마스터 복제 =====")

    copied = base.copy_master(
        target
    )

    print(
        "복사 파일:",
        copied
    )

    # --------------------------------
    # 2. 지역 필터
    # --------------------------------

    print()
    print("===== 2. 지역 필터 =====")

    region_result = remove_regions(
        target,
        cfg
    )

    print(
        "제외 권역:",
        region_result["disabled"]
        if region_result["disabled"]
        else "없음"
    )

    print(
        "삭제 폴더:",
        region_result["removed_dirs"]
    )

    print(
        "삭제 HTML:",
        region_result["removed_html"]
    )

    # --------------------------------
    # 3. 치환표 생성
    # --------------------------------

    new_domain = (
        base.normalize_domain(
            cfg.get("domain")
        )
    )

    replacements = []

    template_domains = (
        base.discover_template_domains()
    )

    if new_domain:

        for old_domain in template_domains:

            if old_domain != new_domain:

                replacements.append(
                    (
                        old_domain,
                        new_domain
                    )
                )

    brand = cfg.get(
        "brand",
        {}
    )

    old_brand = (
        brand.get("old")
        or ""
    ).strip()

    new_brand = (
        brand.get("new")
        or ""
    ).strip()

    if old_brand and new_brand:

        replacements.append(
            (
                old_brand,
                new_brand
            )
        )

    shops_cfg = cfg.get(
        "shops",
        {}
    )

    final_names = {}

    for sid,old in (
        base.TEMPLATE_SHOPS.items()
    ):

        item = shops_cfg.get(
            sid,
            {}
        )

        new_name = (
            item.get("name")
            or old["name"]
        ).strip()

        new_phone = (
            item.get("phone")
            or old["phone"]
        ).strip()

        final_names[sid] = new_name

        if new_name != old["name"]:

            replacements.append(
                (
                    old["name"],
                    new_name
                )
            )

            replacements.append(
                (
                    quote(
                        old["name"],
                        safe=""
                    ),
                    quote(
                        new_name,
                        safe=""
                    )
                )
            )

        if new_phone != old["phone"]:

            replacements.append(
                (
                    old["phone"],
                    new_phone
                )
            )

    # 디자인
    design = cfg.get(
        "design",
        {}
    )

    for old,new in design.get(
        "colors",
        {}
    ).items():

        old = str(old).strip()
        new = str(new).strip()

        if old and new and old != new:

            replacements.append(
                (
                    old,
                    new
                )
            )

            replacements.append(
                (
                    old.lower(),
                    new
                )
            )

    for old,new in design.get(
        "images",
        {}
    ).items():

        old = str(old).strip()
        new = str(new).strip()

        if old and new and old != new:

            replacements.append(
                (
                    old,
                    new
                )
            )

    # 사용자 추가 치환
    for old,new in cfg.get(
        "text_replacements",
        {}
    ).items():

        if str(old):

            replacements.append(
                (
                    str(old),
                    str(new)
                )
            )

    print()
    print("===== 3. 자동 치환 =====")

    changed_files, changes = (
        base.replace_in_text_files(
            target,
            replacements
        )
    )

    print(
        "수정 파일:",
        changed_files
    )

    print(
        "총 치환:",
        changes
    )

    # --------------------------------
    # 4. rewrite
    # --------------------------------

    print()
    print("===== 4. 기존 공통 rewrite 준비 =====")

    base.update_shop_rewrites(
        target,
        final_names
    )

    print(
        "업체 rewrite:",
        len(final_names)
    )

    # --------------------------------
    # 5. sitemap 필터
    # --------------------------------

    print()
    print("===== 5. sitemap 지역 정리 =====")

    sitemap_result = (
        filter_sitemap(
            target,
            cfg
        )
    )

    print(
        "기존 URL:",
        sitemap_result["before"]
    )

    print(
        "삭제 URL:",
        sitemap_result["removed"]
    )

    print(
        "최종 URL:",
        sitemap_result["after"]
    )

    # --------------------------------
    # 6. 제거 지역 링크 자동정리
    # --------------------------------

    print()
    print("===== 6. 제거 지역 링크 자동정리 =====")

    cleanup_result = (
        remove_disabled_region_links(
            target,
            cfg
        )
    )

    print(
        "수정 HTML:",
        cleanup_result["changed_files"]
    )

    print(
        "삭제 링크:",
        cleanup_result["removed_links"]
    )

    print()
    print("===== 6-1. 제거 지역 링크 재검사 =====")

    link_result = (
        scan_disabled_links(
            target,
            cfg
        )
    )

    print(
        "제거 지역을 가리키는 링크:",
        link_result["count"]
    )

    if link_result["samples"]:

        print()
        print(
            "===== 링크 샘플 ====="
        )

        for file,href,region in (
            link_result["samples"]
        ):

            print(
                region,
                "|",
                file
            )

            print(
                " ->",
                href
            )

    # --------------------------------
    # 새 사이트 제목·설명·본문 생성
    # 공개파일 생성 전에 숫자폴더 원본부터 수정
    # --------------------------------

    print()
    print("===== 새 홈페이지 고유본문 생성 =====")

    content_seed = str(
        cfg.get("content_seed")
        or cfg.get("domain")
        or target.name
    ).strip()

    print("본문 생성 식별값:", content_seed)

    content_result = generate_content(
        target,
        content_seed
    )

    print(
        "고유본문 수정 페이지:",
        content_result.get("changed", 0)
    )

    # --------------------------------
    # 업체명 공개 URL 자동생성
    # --------------------------------

    print()
    print("===== 업체 canonical sitemap 자동보완 =====")

    sitemap_shop_result = sync_indexable_shop_urls(target)

    print(
        "sitemap 추가 URL:",
        sitemap_shop_result["added"]
    )

    print()
    print("===== 업체명 공개파일 자동생성 =====")

    public_result = materialize_shop_urls(target)

    print()
    print("===== 숫자 URL canonical 301 생성 =====")

    redirect_result = build_canonical_redirects(target)

    print(
        "새로 생성된 공개파일:",
        public_result["created"]
    )

    # --------------------------------
    # 7. 기존 검사
    # --------------------------------

    print()
    print("===== 7. 최종 구조 검사 =====")

    result = base.validate_output(
        target,
        final_names,
        new_domain
    )

    print(
        "HTML:",
        result["html"]
    )

    print(
        "sitemap:",
        result["sitemap_exists"]
    )

    print(
        "sitemap URL:",
        result["sitemap_urls"]
    )

    print(
        "_redirects:",
        result["redirects_exists"]
    )

    print("canonical 301:", redirect_result["created"])

    print("301 검증:", redirect_result["verified"])

    print()
    print("=" * 78)
    print("V2 생성 완료")
    print("=" * 78)
    print(target)


if __name__ == "__main__":
    main()
