﻿import re
from pathlib import Path
from collections import Counter, defaultdict

import factory_v3_region_engine_v3 as v3
import factory_v3_html_preview as base

ROOT = Path(r"E:\massage-auto-test")


def corrected_context(relative, text):
    info = v3.ORIGINAL_CONTEXT(relative, text)
    parts = Path(relative).parts

    tokens = []
    region = v3.REGION_NAMES.get(parts[1], "")

    if region:
        tokens.append(region)

    for name in v3.engine.breadcrumbs(text):
        incoming = v3.normalize_name(name)

        if incoming:
            tokens = v3.join_without_overlap(tokens, incoming)

    # 기존 오류: "경기 안산시"를 한 덩어리로 다시 추가하던 부분 수정
    short_tokens = v3.normalize_name(info["short_area"])

    if not short_tokens:
        short_tokens = [info["short_area"]]

    tokens = v3.join_without_overlap(tokens, short_tokens)

    cleaned = []

    for token in tokens:
        if not cleaned or cleaned[-1] != token:
            cleaned.append(token)

    # 끝에 같은 지역명 묶음이 반복되면 제거
    changed = True

    while changed:
        changed = False

        for size in range(1, len(cleaned) // 2 + 1):
            if cleaned[-2 * size:-size] == cleaned[-size:]:
                cleaned = cleaned[:-size]
                changed = True
                break

    area = " ".join(cleaned).strip()

    if not area:
        raise ValueError("지역명 정리 실패")

    info["area"] = area
    return info


def generate(relative, text, profile):
    kind = v3.engine.old.classify(relative)

    previous_context = v3.engine.context
    v3.engine.context = corrected_context

    try:
        updated, info = v3.engine.generate(
            relative,
            text,
            profile
        )
    finally:
        v3.engine.context = previous_context

    # 메인·출장 권역·일반 권역에는 상세페이지용 area가 없음
    if kind in {"home", "region"}:
        return updated, info

    # A유형 출장 상세 설명은 일반 마사지와 구분
    if profile == "A" and relative.startswith("special/"):
        area = info["area"]
        places = v3.engine.old.get_places(text)

        if places:
            place_text = "·".join(places)

            description = (
                f"{area} 출장 마사지 지역정보를 "
                f"{place_text} 생활권을 중심으로 정리했습니다. "
                "세부 지역을 선택하고 연결된 업체 안내를 "
                "살펴보세요."
            )
        else:
            description = (
                f"{area} 출장 마사지 관련 지역정보를 "
                "확인하세요. 현재 위치와 주변 생활권을 "
                "살펴보고 연결된 이용안내로 이동할 수 있습니다."
            )

        updated = base.meta_update(
            updated,
            "description",
            description
        )

        updated = base.meta_update(
            updated,
            "og:description",
            description
        )

        info["description"] = description

    return updated, info


def links(text):
    return re.findall(
        r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
        text,
        re.I | re.S
    )


def canonical(text):
    return re.findall(
        r'<link\b[^>]*\brel\s*=\s*["\']canonical["\'][^>]*>',
        text,
        re.I | re.S
    )


def main():
    files = [ROOT / "index.html"]

    for section in ("massage", "special"):
        folder = ROOT / section

        if folder.is_dir():
            files.extend(sorted(folder.rglob("index.html")))

    stats = Counter()
    failures = []

    values = {
        ("A", "title"): defaultdict(list),
        ("A", "description"): defaultdict(list),
        ("B", "title"): defaultdict(list),
        ("B", "description"): defaultdict(list),
    }

    samples = {
        "massage/gyeonggi/ansan/danwon-gu/index.html",
        "massage/gyeonggi/ansan/danwon-gu/고잔동/index.html",
        "special/gyeonggi/ansan/index.html",
        "special/seoul/index.html",
        "special/gyeonggi/index.html",
        "special/incheon/index.html",
    }

    for path in files:
        relative = path.relative_to(ROOT).as_posix()

        if v3.engine.old.classify(relative) is None:
            stats["제외"] += 1
            continue

        stats["검사"] += 1
        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        try:
            results = {}

            for profile in ("A", "B"):
                updated, info = generate(
                    relative,
                    text,
                    profile
                )

                if updated == text:
                    raise ValueError("변경 결과 없음")

                if links(text) != links(updated):
                    raise ValueError("링크 변경 감지")

                if canonical(text) != canonical(updated):
                    raise ValueError("canonical 변경 감지")

                results[profile] = info

            # A와 B 모두 성공한 페이지만 중복 집계
            for profile, info in results.items():
                for field in ("title", "description"):
                    values[
                        (profile, field)
                    ][info[field]].append(relative)

            stats["성공"] += 1

            if relative in samples:
                print()
                print("파일:", relative)

                for profile in ("A", "B"):
                    print(profile, "TITLE:", results[profile]["title"])
                    print(
                        profile,
                        "DESCRIPTION:",
                        results[profile]["description"]
                    )

        except Exception as exc:
            stats["실패"] += 1

            if len(failures) < 20:
                failures.append((relative, str(exc)))

    print()
    print("=" * 68)
    print("V3 지역 생성기 V4 전체 검사")
    print("=" * 68)

    print("검사:", stats["검사"])
    print("성공:", stats["성공"])
    print("실패:", stats["실패"])
    print("경로 제외:", stats["제외"])

    for (profile, field), groups in values.items():
        duplicate_count = sum(
            len(paths) - 1
            for paths in groups.values()
            if len(paths) > 1
        )

        print(
            profile,
            field.upper(),
            "중복:",
            duplicate_count
        )

    print()
    print("실패 사례:")

    for relative, reason in failures:
        print(relative, "=>", reason)

    print()
    print("검사 완료 / 홈페이지 HTML 변경 없음")
    print("V2 및 이전 V3 파일 변경 없음")


if __name__ == "__main__":
    main()
