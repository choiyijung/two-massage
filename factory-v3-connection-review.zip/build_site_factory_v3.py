﻿import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from collections import Counter
from pathlib import Path

import factory_v3_content_v5 as v3
import factory_v3_region_engine_v2 as region_base

FACTORY = Path(r"E:\massage-auto-test")
OUTPUT_BASE = Path(r"D:\massage-sites")
V2_SCRIPT = FACTORY / "build_site_factory_v2.py"

LINK_RE = re.compile(
    r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
    re.I | re.S
)

CANONICAL_RE = re.compile(
    r'<link\b[^>]*\brel\s*=\s*["\']canonical["\'][^>]*>',
    re.I | re.S
)


def ensure_output_location(target):
    allowed = OUTPUT_BASE.resolve()
    resolved = target.resolve()

    if resolved == allowed or allowed not in resolved.parents:
        raise RuntimeError(
            "안전상 새 홈페이지는 D:\\massage-sites 아래에만 생성합니다."
        )

    if resolved == FACTORY.resolve():
        raise RuntimeError("마스터 폴더는 수정할 수 없습니다.")


def collect_pages(target):
    pages = [target / "index.html"]

    for section in ("massage", "special"):
        folder = target / section

        if folder.is_dir():
            pages.extend(sorted(folder.rglob("index.html")))

    selected = []

    for path in pages:
        if not path.is_file():
            continue

        relative = path.relative_to(target).as_posix()

        if region_base.old.classify(relative) is not None:
            selected.append((relative, path))

    if not selected:
        raise RuntimeError("V3 콘텐츠 대상 페이지가 없습니다.")

    if not (target / "index.html").is_file():
        raise RuntimeError("메인 index.html이 없습니다.")

    return selected


def prepare_changes(target, profile):
    pages = collect_pages(target)

    changes = []
    titles = Counter()
    descriptions = Counter()
    types = Counter()

    for relative, path in pages:
        original = path.read_text(
            encoding="utf-8",
            errors="strict"
        )

        changed, info = v3.generate(
            relative,
            original,
            profile
        )

        if changed == original:
            raise RuntimeError(
                f"콘텐츠가 변경되지 않음: {relative}"
            )

        if LINK_RE.findall(original) != LINK_RE.findall(changed):
            raise RuntimeError(
                f"링크 변경 감지: {relative}"
            )

        if CANONICAL_RE.findall(original) != CANONICAL_RE.findall(changed):
            raise RuntimeError(
                f"canonical 변경 감지: {relative}"
            )

        titles[info["title"]] += 1
        descriptions[info["description"]] += 1
        types[info.get("type", region_base.old.classify(relative) or "unknown")] += 1

        changes.append(
            (relative, path, original, changed, info)
        )

    duplicate_titles = sum(
        count - 1
        for count in titles.values()
        if count > 1
    )

    duplicate_descriptions = sum(
        count - 1
        for count in descriptions.values()
        if count > 1
    )

    print()
    print("=" * 68)
    print("V3 콘텐츠 적용 사전검사")
    print("=" * 68)
    print("대상 HTML:", len(changes))
    print("TITLE 중복:", duplicate_titles)
    print("DESCRIPTION 중복:", duplicate_descriptions)
    print("유형별:", dict(types))

    if duplicate_titles or duplicate_descriptions:
        raise RuntimeError(
            "제목 또는 설명 중복이 있어 HTML을 수정하지 않습니다."
        )

    print()
    print("생성 샘플:")

    for relative, path, original, changed, info in changes[:5]:
        print()
        print("파일:", relative)
        print("TITLE:", info["title"])
        print("DESCRIPTION:", info["description"])

    return changes


def apply_changes(target, changes):
    backup = (
        target.parent
        / (target.name + ".v3-region-before")
    )

    if backup.exists():
        raise RuntimeError(
            f"기존 백업이 있어 덮어쓰지 않습니다: {backup}"
        )

    # 백업을 먼저 완성
    for relative, path, original, changed, info in changes:
        backup_path = backup / relative
        backup_path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        shutil.copy2(
            path,
            backup_path
        )

    print()
    print("V3 적용 전 백업:", backup)

    modified = []

    try:
        for relative, path, original, changed, info in changes:
            temp = path.with_name(
                path.name + ".v3-writing"
            )

            temp.write_text(
                changed,
                encoding="utf-8"
            )

            os.replace(
                temp,
                path
            )

            modified.append(
                (relative, path)
            )

    except Exception:
        print("쓰기 오류 발생: 수정된 지역페이지를 복구합니다.")

        for relative, path in reversed(modified):
            shutil.copy2(
                backup / relative,
                path
            )

        raise

    print()
    print("=" * 68)
    print("V3 지역 콘텐츠 적용 완료")
    print("=" * 68)
    print("수정 HTML:", len(modified))
    print("결과 폴더:", target)
    print("지역페이지 백업:", backup)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--config",
        type=Path
    )

    parser.add_argument(
        "--profile",
        choices=["A", "B"],
        required=True
    )

    parser.add_argument(
        "--check-target",
        type=Path,
        help="기존 테스트 홈페이지를 수정하지 않고 검사"
    )

    args = parser.parse_args()

    if args.check_target is not None:
        target = args.check_target.resolve()
        ensure_output_location(target)

        if not target.is_dir():
            raise RuntimeError(
                f"테스트 폴더가 없습니다: {target}"
            )

        prepare_changes(
            target,
            args.profile
        )

        print()
        print("검사 전용 모드 완료")
        print("HTML 변경 없음")
        print("백업 폴더 생성 없음")
        return

    if args.config is None:
        parser.error(
            "새 홈페이지 생성에는 --config가 필요합니다."
        )

    config_path = args.config.resolve()

    with config_path.open(
        "r",
        encoding="utf-8-sig"
    ) as file:
        config = json.load(file)

    if "target" not in config:
        raise RuntimeError(
            "CONFIG에 target 항목이 없습니다."
        )

    target = Path(
        config["target"]
    ).resolve()

    ensure_output_location(target)

    if target.exists():
        raise RuntimeError(
            f"결과 폴더가 이미 존재합니다. 덮어쓰지 않습니다: {target}"
        )

    if not V2_SCRIPT.is_file():
        raise RuntimeError(
            "V2 자동제작기를 찾을 수 없습니다."
        )

    print("=" * 68)
    print("V3 홈페이지 제작 시작")
    print("=" * 68)
    print("CONFIG:", config_path)
    print("콘텐츠 유형:", args.profile)
    print("결과 폴더:", target)

    # V2의 복제·업체정보·사이트맵·301 생성 기능 사용
    result = subprocess.run(
        [
            sys.executable,
            str(V2_SCRIPT),
            "--config",
            str(config_path)
        ],
        cwd=str(FACTORY),
        check=False
    )

    if result.returncode != 0:
        raise RuntimeError(
            "V2 생성이 실패했습니다. V3는 적용하지 않았습니다."
        )

    if not target.is_dir():
        raise RuntimeError(
            "V2 결과 폴더를 찾을 수 없습니다."
        )

    # V2가 완성한 결과물에만 V3 콘텐츠 반영
    changes = prepare_changes(
        target,
        args.profile
    )

    apply_changes(
        target,
        changes
    )

    print()
    print("V3 지역 콘텐츠 연결까지 완료했습니다.")
    print("업체 상세 콘텐츠·디자인 추가 차별화는 다음 단계입니다.")


if __name__ == "__main__":
    main()


