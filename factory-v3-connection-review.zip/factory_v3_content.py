﻿import re
import html
from pathlib import Path

ROOT = Path(r"E:\massage-auto-test")

REGIONS = {
    "seoul": "서울",
    "gyeonggi": "경기",
    "incheon": "인천",
    "other": "기타 지역",
}

SAMPLES = [
    "index.html",
    "massage/seoul/index.html",
    "massage/gyeonggi/index.html",
    "massage/incheon/index.html",
    "special/seoul/index.html",
    "massage/seoul/gangnam-gu/index.html",
    "massage/gyeonggi/ansan/index.html",
]


def clean(value):

    value = re.sub(
        r"<[^>]+>",
        " ",
        value
    )

    value = html.unescape(value)

    return re.sub(
        r"\s+",
        " ",
        value
    ).strip()


def extract(pattern, text):

    m = re.search(
        pattern,
        text,
        re.I | re.S
    )

    if not m:
        return ""

    return clean(
        m.group(1)
    )


def get_title(text):

    return extract(
        r"<title\b[^>]*>(.*?)</title>",
        text
    )


def get_h1(text):

    return extract(
        r"<h1\b[^>]*>(.*?)</h1>",
        text
    )


def get_area(text):

    paragraphs = re.findall(
        r"<p\b[^>]*>(.*?)</p>",
        text,
        re.I | re.S
    )

    for paragraph in paragraphs:

        value = clean(paragraph)

        m = re.fullmatch(
            r"(.+?)\s+생활권 정보",
            value
        )

        if m:
            return m.group(1).strip()

    return ""


def page_type(path):

    parts = Path(path).parts

    if parts == ("index.html",):
        return "home"

    if len(parts) == 3:

        if (
            parts[0] == "massage"
            and parts[1] in REGIONS
        ):
            return "region"

        if (
            parts[0] == "special"
            and parts[1] in REGIONS
        ):
            return "special"

    if (
        len(parts) >= 4
        and parts[0] == "massage"
        and parts[1] in REGIONS
    ):
        return "local"

    return "skip"


def generate_v3_preview(path, text, profile):

    kind = page_type(path)

    if kind == "skip":
        return None

    old_title = get_title(text)
    old_h1 = get_h1(text)

    parts = Path(path).parts

    if kind == "home":

        brand = (
            old_h1.split("|")[-1].strip()
            if "|" in old_h1
            else "마사지 지역안내"
        )

        if profile == "A":

            title = (
                f"전국 마사지 지역 찾기 | "
                f"{brand} 이용 안내"
            )

            description = (
                "서울·경기·인천을 비롯한 전국 마사지 "
                "지역정보를 확인할 수 있습니다. "
                "권역에서 시·군·구와 세부 지역으로 "
                "이동하며 필요한 이용안내를 살펴보세요."
            )

            h1 = (
                "전국 마사지 지역별 안내"
            )

            intro = (
                "현재 위치에 맞는 마사지 지역을 "
                "찾아보세요. 서울과 경기, 인천 등 "
                "권역별 안내에서 시·군·구를 선택하면 "
                "세부 지역과 업체정보를 차례로 "
                "확인할 수 있습니다."
            )

        else:

            title = (
                f"{brand} | "
                "전국 마사지 이용정보와 지역 안내"
            )

            description = (
                "마사지 이용을 알아보는 분들을 위한 "
                "지역별 정보 안내입니다. "
                "이용하려는 지역을 선택하고 "
                "업체별 코스와 문의방법, "
                "예약 전 확인사항을 살펴보세요."
            )

            h1 = (
                "마사지 이용 전 지역과 코스부터 확인하세요"
            )

            intro = (
                "마사지 이용을 준비하고 있다면 "
                "먼저 지역을 선택해보세요. "
                "지역별로 연결된 업체정보와 코스 "
                "안내를 살펴본 뒤 문의 전에 "
                "확인할 내용을 정리할 수 있습니다."
            )

    elif kind in {"region", "special"}:

        area = REGIONS[parts[1]]

        is_special = (
            kind == "special"
        )

        category = (
            "출장 마사지"
            if is_special
            else "마사지"
        )

        if profile == "A":

            title = (
                f"{area} {category} 지역 안내 | "
                "구·시·군별 정보 확인"
            )

            description = (
                f"{area} {category} 관련 지역정보를 "
                "권역별로 정리했습니다. "
                "방문하려는 시·군·구를 선택하고 "
                "세부 지역 안내까지 이어서 "
                "살펴볼 수 있습니다."
            )

            h1 = (
                f"{area} {category} 지역 찾아보기"
            )

            intro = (
                f"{area}에서 이용할 지역을 "
                "선택해보세요. 가까운 시·군·구부터 "
                "확인한 뒤 해당 지역에 연결된 "
                "세부 안내와 업체정보를 "
                "차례로 살펴볼 수 있습니다."
            )

        else:

            title = (
                f"{area} {category} 이용 준비 | "
                "지역 선택과 확인사항"
            )

            description = (
                f"{area}에서 {category} 이용을 "
                "알아볼 때 참고할 지역 안내입니다. "
                "희망 지역을 정한 뒤 코스와 문의방법, "
                "이용 전에 확인할 정보를 살펴보세요."
            )

            h1 = (
                f"{area} 이용 전 지역별 안내 확인"
            )

            intro = (
                f"{area} {category} 이용을 "
                "준비할 때는 먼저 희망 지역을 "
                "정하는 것이 편리합니다. "
                "지역을 선택한 다음 연결된 "
                "업체 안내에서 코스와 문의사항을 "
                "확인해보세요."
            )

    else:

        area = get_area(text)

        if not area:
            return None

        old_head = (
            old_title.split("|")[0].strip()
        )

        if not old_head:
            return None

        if profile == "A":

            title = (
                f"{old_head} | "
                f"{area} 지역별 이용정보"
            )

            description = (
                f"{area}의 마사지 지역정보와 "
                "주변 생활권을 살펴보세요. "
                "현재 위치를 기준으로 세부 지역을 "
                "찾고 업체별 안내로 이동해 "
                "이용정보를 확인할 수 있습니다."
            )

            h1 = (
                f"{area} 마사지 지역 안내"
            )

            intro = (
                f"{area}에서 원하는 지역을 "
                "찾는다면 세부 생활권부터 "
                "확인해보세요. 지역별 안내를 "
                "살펴보면서 현재 위치와 "
                "가까운 곳을 찾아볼 수 있습니다."
            )

        else:

            title = (
                f"{area} 이용 전 확인 | "
                f"{old_head}"
            )

            description = (
                f"{area}에서 마사지 이용을 "
                "준비하는 분들을 위한 안내입니다. "
                "희망 지역을 선택하고 업체별 "
                "코스와 문의방법, 이용 전에 "
                "확인할 내용을 살펴보세요."
            )

            h1 = (
                f"{area}에서 마사지 이용을 준비한다면"
            )

            intro = (
                f"{area} 지역의 마사지 정보를 "
                "알아보고 있다면 이용하려는 "
                "위치를 먼저 정해보세요. "
                "연결된 지역 및 업체 페이지에서 "
                "코스와 이용안내를 "
                "순서대로 확인할 수 있습니다."
            )

    return {
        "type": kind,
        "title": title,
        "description": description,
        "h1": h1,
        "intro": intro,
    }


if __name__ == "__main__":

    print("=" * 72)
    print("V3 콘텐츠 A/B 유형 미리보기")
    print("=" * 72)

    for relative in SAMPLES:

        path = ROOT / relative

        if not path.is_file():
            continue

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        print()
        print("=" * 72)
        print("파일:", relative)
        print("=" * 72)

        for profile in ["A", "B"]:

            result = generate_v3_preview(
                relative,
                text,
                profile
            )

            if result is None:
                print(
                    profile,
                    ": 생성 대상 아님"
                )
                continue

            print()
            print("유형:", profile)
            print("TITLE:", result["title"])
            print(
                "DESCRIPTION:",
                result["description"]
            )
            print("H1:", result["h1"])
            print("소개문:", result["intro"])

    print()
    print("V3 콘텐츠 미리보기 완료")
    print("HTML 수정: 없음")
    print("V2 제작기 수정: 없음")
