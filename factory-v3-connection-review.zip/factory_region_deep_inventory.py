﻿from pathlib import Path
from collections import Counter

ROOT = Path(r"E:\massage-auto-test")

def show_tree(root, max_depth=2):
    if not root.exists():
        print(root.name, "없음")
        return

    print()
    print("=" * 90)
    print(root.name, "구조")
    print("=" * 90)

    rows = []

    for d in sorted(
        [x for x in root.iterdir() if x.is_dir()],
        key=lambda x: x.name.lower()
    ):
        html_count = sum(
            1 for _ in d.rglob("*.html")
        )

        children = sorted(
            [
                x.name
                for x in d.iterdir()
                if x.is_dir()
            ]
        )

        rows.append(
            (
                d.name,
                html_count,
                children[:30]
            )
        )

    print("1단계 폴더:", len(rows))

    for name,count,children in rows:
        print()
        print(
            f"[{name}] HTML {count}"
        )

        if children:
            print(
                "  하위:",
                ", ".join(children)
            )

show_tree(
    ROOT / "massage"
)

show_tree(
    ROOT / "special"
)

print()
print("=" * 90)
print("권역별 직접 루트 수")
print("=" * 90)

SEOUL = {
"gangnam-gu","gangdong-gu","gangbuk-gu","gangseo-gu",
"gwanak-gu","gwangjin-gu","guro-gu","geumcheon-gu",
"nowon-gu","dobong-gu","dongdaemun-gu","dongjak-gu",
"mapo-gu","seodaemun-gu","seocho-gu","seongdong-gu",
"seongbuk-gu","songpa-gu","yangcheon-gu","yeongdeungpo-gu",
"yongsan-gu","eunpyeong-gu","jongno-gu","jung-gu","jungnang-gu"
}

GYEONGGI = {
"ansan","anseong","anyang","bucheon","dongducheon",
"gapyeong","gimpo","goyang","gunpo","guri",
"gwacheon","gwangju-gyeonggi","gwangmyeong","hanam",
"hwaseong","icheon","namyangju","osan","paju","pocheon",
"pyeongtaek","seongnam","siheung","suwon","uijeongbu",
"uiwang","yangju","yangpyeong","yeoju","yeoncheon","yongin"
}

INCHEON = {
"bupyeong-gu","ganghwa-gun","geomdan-gu","gyeyang-gu",
"jemulpo-gu","michuhol-gu","namdong-gu","ongjin-gun",
"seohae-gu","yeongjong-gu","yeonsu-gu"
}

OTHER = {
"asan","changwon","cheonan","cheongju","daegu","daejeon",
"gimhae","gongju","gwangju","gyeryong","iksan","jeonju"
}

for name, group in [
    ("서울", SEOUL),
    ("경기", GYEONGGI),
    ("인천", INCHEON),
    ("기타지역", OTHER)
]:
    found = [
        x for x in group
        if (ROOT / x).exists()
    ]

    htmls = sum(
        sum(
            1 for _ in (ROOT / x).rglob("*.html")
        )
        for x in found
    )

    print(
        name,
        "| 폴더",
        len(found),
        "| HTML",
        htmls
    )

print()
print("조사 완료")
