﻿from pathlib import Path
from collections import Counter
import re

ROOT = Path(r"E:\massage-auto-test")

IGNORE = {
    ".git",
    ".netlify",
    "node_modules",
    "__pycache__",
    "assets"
}

def ignored(p):
    for part in p.relative_to(ROOT).parts:
        if part in IGNORE:
            return True
        if part.startswith("_backup"):
            return True
        if part.startswith("_auto_backup"):
            return True
    return False

rows = []

for d in sorted(ROOT.iterdir(), key=lambda x: x.name.lower()):

    if not d.is_dir():
        continue

    if d.name in IGNORE:
        continue

    if d.name.startswith("_backup") or d.name.startswith("_auto_backup"):
        continue

    htmls = [
        p for p in d.rglob("*.html")
        if not ignored(p)
    ]

    if not htmls:
        continue

    sample = ""

    for p in htmls[:20]:
        try:
            text = p.read_text(
                encoding="utf-8",
                errors="ignore"
            )

            m = re.search(
                r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)',
                text,
                re.I
            )

            if m:
                sample = m.group(1)
                break
        except:
            pass

    rows.append(
        (
            d.name,
            len(htmls),
            sample
        )
    )

print("=" * 100)
print("자동제작 마스터 지역 구조")
print("=" * 100)

print("지역성 루트 폴더:", len(rows))
print("루트별 HTML 합계:", sum(x[1] for x in rows))

print()
print("===== 루트 폴더별 =====")

for name,count,sample in rows:
    print(f"{name:28} | HTML {count:5} | {sample}")

print()
print("=" * 100)
print("총 HTML")
print("=" * 100)

all_html = [
    p for p in ROOT.rglob("*.html")
    if not ignored(p)
]

print(len(all_html))

print()
print("조사 완료")
