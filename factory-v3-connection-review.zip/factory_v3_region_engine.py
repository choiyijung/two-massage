﻿import re
import html
from pathlib import Path
from collections import Counter

import factory_v3_html_preview as base

ROOT = Path(r"E:\massage-auto-test")
OUT = Path(r"D:\massage-sites")

REGIONS = {"seoul", "gyeonggi", "incheon", "other"}

REGION_NAMES = {
    "seoul": "서울",
    "gyeonggi": "경기",
    "incheon": "인천",
    "other": "기타 지역",
}

PROVINCES = (
    "서울|경기|인천|강원|충북|충남|전북|전남|"
    "경북|경남|부산|대구|대전|광주|울산|세종|제주"
)

FULL_AREA_RE = re.compile(
    rf"(?:{PROVINCES})\s+"
    r"(?:[가-힣0-9]+(?:시|군|구|읍|면|동)\s*){1,4}"
)

P_RE = re.compile(
    r"(<p\b[^>]*>)(.*?)(</p>)",
    re.I | re.S
)

TITLE_RE = re.compile(
    r"(<title\b[^>]*>)(.*?)(</title>)",
    re.I | re.S
)

H1_RE = re.compile(
    r"(<h1\b[^>]*>)(.*?)(</h1>)",
    re.I | re.S
)


def clean(value):
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(
        r"\s+", " ",
        html.unescape(value)
    ).strip()


def paragraphs(text):
    return [
        clean(m.group(2))
        for m in P_RE.finditer(text)
    ]


def classify(relative):
    parts = Path(relative).parts

    if parts == ("index.html",):
        return "home"

    if (
        len(parts) < 3
        or parts[0] not in {"massage", "special"}
        or parts[1] not in REGIONS
        or parts[-1] != "index.html"
    ):
        return None

    if len(parts) == 3:
        return "region"

    last_area = parts[-2]

    if last_area.endswith("-gu"):
        return "district"

    if len(parts) >= 6:
        return "neighborhood"

    if len(parts) == 5:
        return "neighborhood"

    return "city"


def get_area(text):
    pp = paragraphs(text)

    if len(pp) < 4:
        raise ValueError("지역 본문 P 태그 4개 미만")

    match = re.fullmatch(
        r"(.+?)\s+생활권 정보",
        pp[2]
    )

    if not match:
        raise ValueError("P3 지역명 추출 실패")

    short_area = match.group(1).strip()

    full_match = FULL_AREA_RE.search(
        pp[1] + " " + pp[2]
    )

    full_area = (
        full_match.group(0).strip()
        if full_match
        else short_area
    )

    if not full_area.endswith(short_area):
        full_area = short_area

    return full_area, pp


def get_places(text):
    pp = paragraphs(text)

    if len(pp) < 2:
        return []

    match = re.search(
        r"^(.+?)\s+생활권을 기준",
        pp[1]
    )

    if not match:
        return []

    raw = match.group(1)

    raw = re.sub(
        r"(?<=[가-힣])(?:와|과)\s+",
        ", ",
        raw
    )

    names = [
        x.strip()
        for x in raw.split(",")
        if x.strip()
    ]

    if len(names) < 2:
        return []

    return names[:3]


def update_html(text, title, description, h1, intro, detail=None):
    updated, count = TITLE_RE.subn(
        lambda m:
            m.group(1)
            + html.escape(title)
            + m.group(3),
        text,
        count=1
    )

    if count != 1:
        raise ValueError("TITLE 수정 실패")

    for key, value in (
        ("description", description),
        ("og:title", title),
        ("og:description", description),
    ):
        updated = base.meta_update(
            updated,
            key,
            value
        )

    updated, count = H1_RE.subn(
        lambda m:
            m.group(1)
            + html.escape(h1)
            + m.group(3),
        updated,
        count=1
    )

    if count != 1:
        raise ValueError("H1 수정 실패")

    updated = base.replace_p(
        updated,
        2,
        intro
    )

    if detail is not None:
        updated = base.replace_p(
            updated,
            4,
            detail
        )

    return updated


def generate(relative, text, profile):
    kind = classify(relative)

    if kind is None:
        raise ValueError("V3 대상 경로가 아님")

    # 메인·권역은 기존에 성공한 생성 규칙 유지
    if kind in {"home", "region"}:
        return base.generate(
            relative,
            text,
            profile
        )

    area, pp = get_area(text)
    places = get_places(text)

    section = Path(relative).parts[0]

    category = (
        "출장 마사지"
        if section == "special"
        else "마사지"
    )

    old_title_match = TITLE_RE.search(text)

    if not old_title_match:
        raise ValueError("기존 TITLE 없음")

    old_topic = clean(
        old_title_match.group(2)
    ).split("|")[0].strip()

    place_text = "·".join(places)

    if profile == "A":

        if places:
            title = (
                f"{area} {category} 생활권 안내 | "
                f"{place_text} 지역 찾기"
            )

            description = (
                f"{area}의 {place_text} 생활권을 "
                "중심으로 지역정보를 살펴보세요. "
                "세부 지역을 선택하고 연결된 "
                "업체별 이용안내를 확인할 수 있습니다."
            )

            intro = (
                f"{area}에서 {place_text} 생활권을 "
                "기준으로 지역을 찾아보세요. "
                "현재 위치에 맞는 세부 지역과 "
                "업체 안내를 차례로 살펴볼 수 있습니다."
            )

        else:
            title = (
                f"{area} {category} 지역 안내 | "
                "생활권과 세부 지역 확인"
            )

            description = (
                f"{area}의 {category} 지역정보와 "
                "주변 생활권을 정리했습니다. "
                "현재 위치를 기준으로 가까운 "
                "지역 안내를 확인해보세요."
            )

            intro = (
                f"{area}의 지역정보를 살펴보세요. "
                "현재 위치를 기준으로 해당 지역과 "
                "주변 생활권을 확인하고 연결된 "
                "업체 안내로 이동할 수 있습니다."
            )

        h1 = f"{area} {category} 지역 찾아보기"

        detail = None

        if kind == "city" and places:
            detail = (
                f"{area}의 {place_text} 등 "
                "지역별 안내를 통해 현재 위치와 "
                "가까운 생활권을 먼저 확인해보세요. "
                "필요한 경우 연결된 세부 지역까지 "
                "범위를 넓혀 살펴볼 수 있습니다."
            )

    else:

        title = (
            f"{area} {category} 이용 안내 | "
            "코스와 문의 전 확인사항"
        )

        if places:
            area_info = (
                f"{place_text} 등 원하는 지역을 정한 뒤 "
            )
        else:
            area_info = (
                "원하는 세부 지역을 정한 뒤 "
            )

        description = (
            f"{area}에서 {category} 이용을 "
            f"준비할 때 참고하세요. {area_info}"
            "업체별 코스와 문의방법을 "
            "확인할 수 있습니다."
        )

        h1 = (
            f"{area} {category} 이용 전 확인할 내용"
        )

        intro = (
            f"{area}에서 {category} 이용을 "
            "알아보고 있다면 희망 위치와 "
            "시간을 먼저 정리해보세요. "
            f"{area_info}"
            "연결된 업체의 코스와 안내사항을 "
            "살펴볼 수 있습니다."
        )

        detail = None

        if kind == "city":
            detail = (
                f"{area}에서 이용 일정을 "
                "계획한다면 업체별 안내를 통해 "
                "코스와 문의방법을 확인해보세요. "
                "실제 이용 가능 시간과 세부 사항은 "
                "상담 시 확인하는 것이 좋습니다."
            )

    updated = update_html(
        text,
        title,
        description,
        h1,
        intro,
        detail
    )

    return updated, {
        "type": kind,
        "title": title,
        "description": description,
        "h1": h1,
        "intro": intro,
    }


def main():
    files = [ROOT / "index.html"]

    for section in ("massage", "special"):
        folder = ROOT / section

        if folder.is_dir():
            files.extend(
                sorted(folder.rglob("index.html"))
            )

    stats = Counter()
    problems = []
    results = {}
    all_titles = {"A": [], "B": []}
    all_descriptions = {"A": [], "B": []}

    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        kind = classify(relative)

        if kind is None:
            stats["경로 제외"] += 1
            continue

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        if re.search(
            r'<meta\b[^>]*http-equiv\s*=\s*'
            r'["\']refresh["\']',
            text,
            re.I
        ):
            stats["이동용 제외"] += 1
            continue

        stats["검사"] += 1
        stats["검사 " + kind] += 1

        try:
            generated = {}

            for profile in ("A", "B"):
                new_text, info = generate(
                    relative,
                    text,
                    profile
                )

                if new_text == text:
                    raise ValueError(
                        profile + " 변경 없음"
                    )

                old_links = re.findall(
                    r'<a\b[^>]*\bhref\s*=\s*'
                    r'(["\'])(.*?)\1',
                    text,
                    re.I | re.S
                )

                new_links = re.findall(
                    r'<a\b[^>]*\bhref\s*=\s*'
                    r'(["\'])(.*?)\1',
                    new_text,
                    re.I | re.S
                )

                if old_links != new_links:
                    raise ValueError(
                        profile + " 링크 변경 감지"
                    )

                generated[profile] = (
                    new_text,
                    info
                )

            stats["성공"] += 1
            stats["성공 " + kind] += 1

            results[relative] = generated

            for profile in ("A", "B"):
                info = generated[profile][1]

                all_titles[profile].append(
                    info["title"]
                )

                all_descriptions[profile].append(
                    info["description"]
                )

        except Exception as exc:
            stats["실패"] += 1
            stats["실패 " + kind] += 1

            if len(problems) < 20:
                problems.append(
                    (relative, str(exc))
                )

    print("=" * 68)
    print("V3 A/B 전체 지역 콘텐츠 생성 검사")
    print("=" * 68)

    for key in (
        "검사",
        "성공",
        "실패",
        "이동용 제외",
        "경로 제외",
    ):
        print(key + ":", stats[key])

    print()
    print("유형별 결과")

    for kind in (
        "home",
        "region",
        "city",
        "district",
        "neighborhood",
    ):
        print(
            kind,
            "검사:",
            stats["검사 " + kind],
            "성공:",
            stats["성공 " + kind],
            "실패:",
            stats["실패 " + kind],
        )

    print()
    print("생성된 제목·설명 내부 중복")

    for profile in ("A", "B"):
        for label, items in (
            ("TITLE", all_titles[profile]),
            ("DESCRIPTION", all_descriptions[profile]),
        ):
            counts = Counter(items)

            duplicate_count = sum(
                n - 1
                for n in counts.values()
                if n > 1
            )

            print(
                profile,
                label,
                "중복:",
                duplicate_count
            )

    print()
    print("실패 사례")

    for relative, reason in problems:
        print(relative, "=>", reason)

    # 전체 검사를 통과한 경우에만 대표 HTML 저장
    if stats["실패"]:
        print()
        print("실패가 있어 미리보기 파일은 저장하지 않았습니다.")
        return

    samples = [
        "index.html",
        "massage/seoul/index.html",
        "massage/seoul/gangnam-gu/index.html",
        "massage/gyeonggi/ansan/index.html",
        "massage/gyeonggi/ansan/danwon-gu/index.html",
        "massage/gyeonggi/ansan/danwon-gu/고잔동/index.html",
        "special/gyeonggi/ansan/index.html",
        "special/gyeonggi/ansan/danwon-gu/index.html",
    ]

    for profile in ("A", "B"):
        target_root = (
            OUT / f"v3-region-engine-preview-{profile}"
        )

        if target_root.exists():
            raise RuntimeError(
                f"기존 결과 폴더가 있습니다: {target_root}"
            )

    saved = 0

    for relative in samples:
        if relative not in results:
            continue

        for profile in ("A", "B"):
            new_text, info = results[relative][profile]

            target = (
                OUT
                / f"v3-region-engine-preview-{profile}"
                / relative
            )

            target.parent.mkdir(
                parents=True,
                exist_ok=True
            )

            target.write_text(
                new_text,
                encoding="utf-8"
            )

            saved += 1

            print()
            print(profile, relative)
            print("TITLE:", info["title"])
            print("H1:", info["h1"])

    print()
    print("대표 HTML 저장:", saved)
    print("마스터 HTML 변경 없음")
    print("V2 제작기 변경 없음")
    print("운영 사이트 변경 없음")


if __name__ == "__main__":
    main()
