﻿import html
import os
import re
import shutil
from pathlib import Path

import factory_v3_region_engine_v4 as previous

FACTORY = Path(r"E:\massage-auto-test")
OUTPUT = Path(r"D:\massage-sites")

P_RE = re.compile(
    r"<p\b[^>]*>.*?</p>",
    re.I | re.S
)

MAIN_H1_RE = re.compile(
    r'(<section\b[^>]*class=["\'][^"\']*\bmain-title-section\b[^"\']*["\'][^>]*>\s*<h1\b[^>]*>.*?</h1>)',
    re.I | re.S
)

LINK_RE = re.compile(
    r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
    re.I | re.S
)


def move_home_intro(original, generated, intro):
    original_p = P_RE.search(original)
    generated_p = P_RE.search(generated)

    if not original_p or not generated_p:
        raise RuntimeError("메인페이지 첫 문단을 확인할 수 없습니다.")

    if "class=\"support\"" not in original[
        max(0, original_p.start() - 250):original_p.start()
    ]:
        raise RuntimeError("첫 문단이 고객센터 영역인지 확인이 필요합니다.")

    current_value = html.unescape(
        re.sub(r"<[^>]+>", "", generated_p.group(0))
    ).strip()

    if current_value != intro.strip():
        raise RuntimeError("이동할 소개문이 일치하지 않습니다.")

    if 'class="v3-home-lead"' in generated:
        raise RuntimeError("V3 메인 소개문이 이미 존재합니다.")

    result = (
        generated[:generated_p.start()]
        + original_p.group(0)
        + generated[generated_p.end():]
    )

    marker = (
        '\n<p class="v3-home-lead" '
        'style="max-width:900px;margin:12px auto 24px;'
        'padding:0 18px;text-align:center;line-height:1.7;">'
        + html.escape(intro)
        + "</p>"
    )

    result, count = MAIN_H1_RE.subn(
        lambda match: match.group(1) + marker,
        result,
        count=1
    )

    if count != 1:
        raise RuntimeError("메인 H1 아래 삽입 위치 확인 실패")

    if LINK_RE.findall(generated) != LINK_RE.findall(result):
        raise RuntimeError("링크 변경 감지")

    return result


def generate(relative, text, profile):
    generated, info = previous.generate(
        relative,
        text,
        profile
    )

    if relative != "index.html":
        return generated, info

    intro = info.get("paragraphs", {}).get(1)

    if not intro:
        raise RuntimeError("메인 소개문 생성 결과가 없습니다.")

    generated = move_home_intro(
        text,
        generated,
        intro
    )

    info["type"] = "home"

    return generated, info


def fix_existing_sites():
    pending = []

    for profile in ("A", "B"):
        site = OUTPUT / f"massage-v3-{profile}"

        current = site / "index.html"

        original = (
            OUTPUT
            / f"massage-v3-{profile}.v3-region-before"
            / "index.html"
        )

        safety = site / "index.html.before-v3-home-fix"

        if not current.is_file() or not original.is_file():
            raise RuntimeError(
                f"{profile}: 현재 메인 또는 V3 적용 전 백업이 없습니다."
            )

        if safety.exists():
            raise RuntimeError(
                f"{profile}: 기존 수정 전 백업이 있습니다. 덮어쓰지 않습니다."
            )

        old_text = original.read_text(encoding="utf-8")
        current_text = current.read_text(encoding="utf-8")

        current_p = P_RE.search(current_text)

        if not current_p:
            raise RuntimeError(f"{profile}: 메인 문단 없음")

        intro = html.unescape(
            re.sub(r"<[^>]+>", "", current_p.group(0))
        ).strip()

        fixed = move_home_intro(
            old_text,
            current_text,
            intro
        )

        pending.append(
            (profile, current, safety, current_text, fixed)
        )

    completed = []

    try:
        for profile, current, safety, old_text, fixed in pending:
            shutil.copy2(current, safety)

            temporary = current.with_name(
                "index.html.v3-home-writing"
            )

            temporary.write_text(
                fixed,
                encoding="utf-8"
            )

            os.replace(
                temporary,
                current
            )

            completed.append((current, safety))

            print()
            print(profile, "메인페이지 수정 완료")
            print("파일:", current)
            print("수정 전 백업:", safety)

    except Exception:
        for current, safety in reversed(completed):
            shutil.copy2(safety, current)
        raise

    print()
    print("A/B 고객센터 문구 복구 완료")
    print("A/B 메인 H1 아래 소개문 삽입 완료")
    print("지역·업체 페이지 변경 없음")


if __name__ == "__main__":
    fix_existing_sites()
