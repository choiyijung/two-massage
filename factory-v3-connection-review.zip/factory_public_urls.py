﻿import re
import html
import shutil
import xml.etree.ElementTree as ET

from pathlib import Path
from urllib.parse import urlparse, unquote

IDS = {"001", "002", "003", "004", "005"}


def get_canonical(text):

    m = re.search(
        r'<link\b[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']+)',
        text,
        re.I | re.S
    )

    return html.unescape(m.group(1)).strip() if m else ""


def materialize_shop_urls(root):

    root = Path(root).resolve()

    if not root.exists():
        raise RuntimeError("생성된 사이트 폴더가 없습니다.")

    forbidden = {
        Path(r"E:\massage-auto-test").resolve(),
        Path(r"E:\seoul-massage-rebuild").resolve()
    }

    if root in forbidden:
        raise RuntimeError("마스터 또는 기존 운영 사이트는 수정할 수 없습니다.")

    files = sorted(
        p for p in root.rglob("index.html")
        if p.parent.name in IDS
        and p.parent.parent.name == "shops"
    )

    create = []
    same = 0
    existed = 0
    problems = []
    destinations = {}

    for src in files:

        text = src.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        canonical = get_canonical(text)

        if not canonical:
            problems.append((src, "canonical 없음"))
            continue

        parsed = urlparse(canonical)

        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.netloc
            or parsed.query
            or parsed.fragment
        ):
            problems.append((src, "canonical 형식 오류"))
            continue

        public_path = unquote(parsed.path)

        if (
            not public_path.startswith("/")
            or not public_path.endswith("/")
            or "\\" in public_path
            or ".." in public_path.split("/")
        ):
            problems.append((src, "공개 경로 오류"))
            continue

        dst = root / public_path.lstrip("/") / "index.html"

        try:
            dst.resolve().relative_to(root)
        except ValueError:
            problems.append((src, "루트 밖 경로"))
            continue

        source_parts = src.relative_to(root).parts
        target_parts = dst.relative_to(root).parts

        if source_parts[:-2] != target_parts[:-2]:
            problems.append((src, "지역 경로 불일치"))
            continue

        key = str(dst).casefold()

        if key in destinations:
            problems.append((src, "공개 경로 중복"))
            continue

        destinations[key] = src

        if dst == src:
            same += 1

        elif dst.exists():

            if dst.read_bytes() == src.read_bytes():
                existed += 1
            else:
                problems.append((src, "기존 공개파일 내용 충돌"))

        else:
            create.append((src, dst, canonical))

    # sitemap 확인
    sitemap = root / "sitemap.xml"
    missing = []

    if sitemap.exists():

        tree = ET.parse(sitemap)
        urls = set()

        for element in tree.getroot().iter():

            if element.tag.rsplit("}", 1)[-1] != "loc":
                continue

            if not element.text:
                continue

            u = urlparse(
                html.unescape(element.text.strip())
            )

            urls.add((
                u.netloc.lower(),
                unquote(u.path).rstrip("/") + "/"
            ))

        for src, dst, canonical in create:

            u = urlparse(canonical)

            key = (
                u.netloc.lower(),
                unquote(u.path).rstrip("/") + "/"
            )

            if key not in urls:
                missing.append(canonical)

    print()
    print("===== 업체명 공개 URL 생성 =====")
    print("검사 업체 페이지 :", len(files))
    print("이미 경로 일치   :", same)
    print("이미 생성된 파일 :", existed)
    print("새로 생성할 파일 :", len(create))
    print("경로 문제        :", len(problems))
    print("sitemap 미포함   :", len(missing))

    if problems:

        for src, reason in problems[:10]:
            print(reason, ":", src)

        raise RuntimeError(
            "업체 공개경로 문제로 생성을 중단했습니다."
        )

    if missing:

        for url in missing[:10]:
            print("sitemap 미포함:", url)

        raise RuntimeError(
            "공개 URL이 sitemap에 없어 생성을 중단했습니다."
        )

    created = 0

    for src, dst, canonical in create:

        dst.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        shutil.copy2(src, dst)

        created += 1

    print("실제 생성 파일   :", created)

    return {
        "checked": len(files),
        "created": created,
        "already_correct": same,
        "already_created": existed,
        "problems": len(problems),
        "sitemap_missing": len(missing)
    }
