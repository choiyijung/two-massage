﻿import re
from pathlib import Path
from collections import Counter, defaultdict

import factory_v3_region_engine_v2 as engine
import factory_v3_html_preview as base

ROOT = Path(r"E:\massage-auto-test")

REGION_NAMES = {
    "seoul": "서울",
    "gyeonggi": "경기",
    "incheon": "인천",
    "other": "",
}

REGION_WORDS = {
    "서울", "경기", "인천", "강원",
    "충북", "충남", "전북", "전남",
    "경북", "경남", "부산", "대구",
    "대전", "광주", "울산", "세종", "제주",
}

AREA_TOKEN = re.compile(
    r"[가-힣0-9.]+(?:시|군|구|읍|면|동)$"
)

ORIGINAL_CONTEXT = engine.context


def normalize_name(name):
    name = name.strip()

    if name in {"홈", "HOME", "전체 지역", "기타 지역"}:
        return []

    result = []

    for token in name.split():

        if token in REGION_WORDS:
            result.append(token)

        elif AREA_TOKEN.fullmatch(token):
            result.append(token)

    if result:
        return result

    # 군산·천안처럼 Breadcrumb에 약칭만 있는 경우
    if (
        len(name.split()) == 1
        and re.fullmatch(r"[가-힣]{2,5}", name)
        and not any(
            word in name
            for word in (
                "마사지", "테라피", "힐링",
                "케어", "지역", "안내"
            )
        )
    ):
        return [name]

    return []


def join_without_overlap(existing, incoming):

    if not existing:
        return incoming[:]

    for overlap in range(
        min(len(existing), len(incoming)),
        0,
        -1
    ):
        if existing[-overlap:] == incoming[:overlap]:
            return existing + incoming[overlap:]

    return existing + incoming


def corrected_context(relative, text):

    info = ORIGINAL_CONTEXT(relative, text)

    parts = Path(relative).parts

    tokens = []

    region = REGION_NAMES.get(parts[1], "")

    if region:
        tokens.append(region)

    names = engine.breadcrumbs(text)

    for name in names:
        incoming = normalize_name(name)

        tokens = join_without_overlap(
            tokens,
            incoming
        )

    short_area = info["short_area"]

    if not tokens or tokens[-1] != short_area:
        tokens.append(short_area)

    # 인접한 동일 지역명만 제거
    cleaned = []

    for token in tokens:
        if not cleaned or cleaned[-1] != token:
            cleaned.append(token)

    full_area = " ".join(cleaned)

    if not full_area:
        raise ValueError("지역명 정리 실패")

    if re.search(
        r"지역별|마사지|테라피|힐링|케어",
        full_area
    ):
        raise ValueError(
            f"지역명에 콘텐츠 문구 혼입: {full_area}"
        )

    info["area"] = full_area

    return info


def generate(relative, text, profile):

    previous = engine.context

    engine.context = corrected_context

    try:
        updated, info = engine.generate(
            relative,
            text,
            profile
        )
    finally:
        engine.context = previous

    # 일반 마사지와 출장 마사지의 설명이 같아지는 문제 수정
    if (
        profile == "A"
        and relative.startswith("special/")
        and info.get("type") not in {"home", "region"}
    ):

        old_description = info["description"]
        area = info["area"]

        if old_description.startswith(area + "의 "):
            new_description = (
                area
                + " 출장 마사지 관련 "
                + old_description[len(area + "의 "):]
            )
        else:
            new_description = (
                "출장 마사지 지역 안내. "
                + old_description
            )

        updated = base.meta_update(
            updated,
            "description",
            new_description
        )

        updated = base.meta_update(
            updated,
            "og:description",
            new_description
        )

        info["description"] = new_description

    return updated, info


def main():

    files = [ROOT / "index.html"]

    for section in ("massage", "special"):
        folder = ROOT / section

        if folder.is_dir():
            files.extend(
                sorted(folder.rglob("index.html"))
            )

    counts = Counter()
    failures = []

    values = {
        ("A", "title"): defaultdict(list),
        ("A", "description"): defaultdict(list),
        ("B", "title"): defaultdict(list),
        ("B", "description"): defaultdict(list),
    }

    samples = {
        "massage/gyeonggi/ansan/danwon-gu/index.html",
        "massage/gyeonggi/ansan/danwon-gu/고잔동/index.html",
        "massage/other/gunsan/개정동/index.html",
        "massage/other/changwon/seongsan-gu/중앙동/index.html",
        "massage/other/cheonan/dongnam-gu/중앙동/index.html",
        "special/gyeonggi/ansan/index.html",
    }

    for path in files:

        relative = path.relative_to(ROOT).as_posix()

        if engine.old.classify(relative) is None:
            counts["제외"] += 1
            continue

        counts["검사"] += 1

        text = path.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        try:

            for profile in ("A", "B"):

                updated, info = generate(
                    relative,
                    text,
                    profile
                )

                if updated == text:
                    raise ValueError("변경 결과 없음")

                old_links = re.findall(
                    r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
                    text,
                    re.I | re.S
                )

                new_links = re.findall(
                    r'<a\b[^>]*\bhref\s*=\s*(["\'])(.*?)\1',
                    updated,
                    re.I | re.S
                )

                if old_links != new_links:
                    raise ValueError("링크 변경 감지")

                for field in ("title", "description"):

                    values[
                        (profile, field)
                    ][info[field]].append(relative)

                if relative in samples:

                    print()
                    print("파일:", relative)
                    print("유형:", profile)
                    print("TITLE:", info["title"])
                    print(
                        "DESCRIPTION:",
                        info["description"]
                    )

            counts["성공"] += 1

        except Exception as exc:

            counts["실패"] += 1

            if len(failures) < 20:
                failures.append(
                    (relative, str(exc))
                )

    print()
    print("=" * 70)
    print("V3 지역명·중복 보완 검사")
    print("=" * 70)

    print("검사:", counts["검사"])
    print("성공:", counts["성공"])
    print("실패:", counts["실패"])
    print("경로 제외:", counts["제외"])

    print()
    print("제목·설명 내부 중복")

    for (profile, field), groups in values.items():

        duplicate_count = sum(
            len(paths) - 1
            for paths in groups.values()
            if len(paths) > 1
        )

        print(
            profile,
            field.upper(),
            "중복:",
            duplicate_count
        )

    print()
    print("실패 사례")

    for relative, reason in failures:
        print(relative, "=>", reason)

    print()
    print("검사 완료")
    print("홈페이지 HTML 수정 없음")
    print("기존 V2·V3 파일 수정 없음")


if __name__ == "__main__":
    main()
