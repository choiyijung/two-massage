﻿import re
import html
import shutil
import xml.etree.ElementTree as ET

from pathlib import Path
from urllib.parse import urlparse, unquote

ROOT = Path(r"E:\massage-seoul-resume-test")

IDS = {"001", "002", "003", "004", "005"}

if not ROOT.exists():
    raise SystemExit("테스트 폴더가 없습니다.")

MASTER = Path(r"E:\massage-auto-test").resolve()
ORIGINAL = Path(r"E:\seoul-massage-rebuild").resolve()

if ROOT.resolve() in {MASTER, ORIGINAL}:
    raise SystemExit("마스터 또는 기존 운영 사이트는 수정할 수 없습니다.")

def read(p):
    return p.read_text(
        encoding="utf-8",
        errors="ignore"
    )

def get_canonical(text):
    m = re.search(
        r'<link\b[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']+)',
        text,
        re.I | re.S
    )

    return html.unescape(m.group(1)).strip() if m else ""

files = sorted(
    p for p in ROOT.rglob("index.html")
    if p.parent.name in IDS
    and p.parent.parent.name == "shops"
)

to_create = []
already_correct = 0
already_created = 0
problems = []

destinations = {}

for src in files:

    canonical = get_canonical(read(src))

    if not canonical:
        problems.append((src, "canonical 없음"))
        continue

    parsed = urlparse(canonical)

    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.netloc
        or parsed.query
        or parsed.fragment
    ):
        problems.append((src, "canonical 형식 오류"))
        continue

    path = unquote(parsed.path)

    if (
        "\\" in path
        or ".." in path.split("/")
        or not path.endswith("/")
    ):
        problems.append((src, "공개 경로 오류"))
        continue

    relative = Path(path.lstrip("/"))
    dst = ROOT / relative / "index.html"

    try:
        dst.resolve().relative_to(ROOT.resolve())
    except ValueError:
        problems.append((src, "루트 밖 경로"))
        continue

    source_parts = src.relative_to(ROOT).parts
    target_parts = dst.relative_to(ROOT).parts

    if source_parts[:-2] != target_parts[:-2]:
        problems.append((src, "지역 경로 불일치"))
        continue

    key = str(dst).casefold()

    if key in destinations:
        problems.append((src, "공개 경로 중복"))
        continue

    destinations[key] = src

    if dst == src:
        already_correct += 1

    elif dst.exists():

        if dst.read_bytes() == src.read_bytes():
            already_created += 1
        else:
            problems.append((src, "기존 공개파일 내용 충돌"))

    else:
        to_create.append((src, dst, canonical))

print("=" * 78)
print("서울 전용 업체명 URL 자동생성")
print("=" * 78)

print("검사 업체 페이지    :", len(files))
print("이미 경로 일치      :", already_correct)
print("이미 생성된 공개파일:", already_created)
print("새로 생성할 파일    :", len(to_create))
print("문제 발생           :", len(problems))

if problems:
    print()
    for src, reason in problems[:20]:
        print(reason, ":", src)

    raise SystemExit(
        "문제가 있어 파일을 생성하지 않았습니다."
    )

created = 0

for src, dst, canonical in to_create:

    dst.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    shutil.copy2(src, dst)

    created += 1

print()
print("===== 업체명 공개파일 생성 완료 =====")

print("생성 파일:", created)
print("전체 HTML:", sum(1 for _ in ROOT.rglob("*.html")))

# sitemap 포함 여부 검사
sitemap = ROOT / "sitemap.xml"

if sitemap.exists():

    tree = ET.parse(sitemap)

    urls = set()

    for element in tree.getroot().iter():

        if element.tag.rsplit("}", 1)[-1] != "loc":
            continue

        if element.text:
            u = urlparse(
                html.unescape(element.text.strip())
            )

            urls.add(
                (
                    u.netloc.lower(),
                    unquote(u.path).rstrip("/") + "/"
                )
            )

    missing = []

    for src, dst, canonical in to_create:

        u = urlparse(canonical)

        key = (
            u.netloc.lower(),
            unquote(u.path).rstrip("/") + "/"
        )

        if key not in urls:
            missing.append(canonical)

    print()
    print("===== sitemap 확인 =====")
    print("sitemap URL:", len(urls))
    print("새 공개 URL 누락:", len(missing))

    if missing:
        print()
        print("누락 샘플:")

        for x in missing[:10]:
            print(x)

print()
print("테스트 폴더:", ROOT)
print("마스터 변경: 없음")
print("기존 운영 사이트 변경: 없음")
