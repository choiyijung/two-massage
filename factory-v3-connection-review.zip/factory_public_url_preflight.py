﻿import re
import html
from pathlib import Path
from urllib.parse import urlparse, unquote
from collections import Counter, defaultdict

ROOT = Path(r"E:\massage-auto-test")

def excluded(p):
    rel = p.relative_to(ROOT)

    return any(
        x.startswith("_backup")
        or x.startswith("_auto_backup")
        or x in {".git", ".netlify", "node_modules"}
        for x in rel.parts
    )

def get_canonical(text):
    m = re.search(
        r'<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)',
        text,
        re.I | re.S
    )

    return html.unescape(m.group(1)).strip() if m else ""

files = sorted(
    p for p in ROOT.rglob("index.html")
    if not excluded(p)
    and p.parent.name in {"001", "002", "003", "004", "005"}
    and p.parent.parent.name == "shops"
)

aliases = defaultdict(list)
hosts = Counter()

already_exists = 0
need_create = 0
invalid = []
existing_conflicts = []

root_resolved = ROOT.resolve()

for p in files:

    text = p.read_text(
        encoding="utf-8",
        errors="ignore"
    )

    canonical = get_canonical(text)

    if not canonical:
        invalid.append((str(p), "canonical 없음"))
        continue

    parsed = urlparse(canonical)
    hosts[parsed.netloc.lower()] += 1

    public_path = unquote(parsed.path)

    if (
        not public_path.startswith("/")
        or not public_path.endswith("/")
        or parsed.query
        or parsed.fragment
        or "\\" in public_path
        or ".." in Path(public_path).parts
    ):
        invalid.append((str(p), canonical))
        continue

    relative = public_path.lstrip("/")

    destination = ROOT / relative / "index.html"

    try:
        if not destination.resolve().is_relative_to(root_resolved):
            invalid.append((str(p), "루트 밖 경로"))
            continue
    except Exception:
        invalid.append((str(p), "경로 검사 실패"))
        continue

    key = str(destination).casefold()

    aliases[key].append(
        (p, destination, canonical)
    )

    if destination == p:
        already_exists += 1

    elif destination.exists():
        existing_conflicts.append(
            (str(p), str(destination))
        )

    else:
        need_create += 1

collisions = {
    key: rows
    for key, rows in aliases.items()
    if len(set(str(x[0]) for x in rows)) > 1
}

print("=" * 75)
print("업체명 공개파일 자동생성 사전검사")
print("=" * 75)

print("숫자폴더 업체 페이지 :", len(files))
print("이미 실제 경로 존재  :", already_exists)
print("새로 생성할 공개파일 :", need_create)
print("기존 파일과 충돌     :", len(existing_conflicts))
print("공개 경로 중복       :", len(collisions))
print("잘못된 canonical     :", len(invalid))

print()
print("===== canonical 도메인 =====")

for host, count in hosts.most_common():
    print(host, ":", count)

if collisions:
    print()
    print("===== 공개 경로 중복 사례 =====")

    for rows in list(collisions.values())[:10]:
        for source, destination, canonical in rows:
            print("원본:", source.relative_to(ROOT))
            print("공개:", canonical)
        print()

if existing_conflicts:
    print()
    print("===== 기존 파일과 충돌 사례 =====")

    for source, destination in existing_conflicts[:10]:
        print("원본:", source)
        print("대상:", destination)

if invalid:
    print()
    print("===== canonical 이상 사례 =====")

    for row in invalid[:10]:
        print(row)

print()
print("사전검사 완료")
