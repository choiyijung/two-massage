﻿import os
import re
import html
import shutil
import xml.etree.ElementTree as ET

from pathlib import Path
from urllib.parse import urlsplit, unquote, quote

from factory_public_urls import get_canonical


MASTER = Path(r"E:\massage-auto-test").resolve()
LIVE = Path(r"E:\seoul-massage-rebuild").resolve()

IDS = {"001", "002", "003", "004", "005"}

START = "# FACTORY CANONICAL 301 START"
END = "# FACTORY CANONICAL 301 END"


def url_key(url):

    u = urlsplit(html.unescape(url).strip())

    return (
        u.netloc.lower(),
        unquote(u.path).rstrip("/") + "/"
    )


def build_canonical_redirects(root):

    root = Path(root).resolve()

    if (
        root == MASTER
        or root.is_relative_to(MASTER)
        or root == LIVE
        or root.is_relative_to(LIVE)
    ):
        raise RuntimeError(
            "마스터 또는 운영 사이트는 수정할 수 없습니다."
        )

    if not root.is_dir():
        raise RuntimeError(
            "생성된 사이트 폴더가 없습니다."
        )

    redirects = root / "_redirects"
    sitemap = root / "sitemap.xml"

    if not redirects.is_file():
        raise RuntimeError("_redirects가 없습니다.")

    if not sitemap.is_file():
        raise RuntimeError("sitemap.xml이 없습니다.")

    original = redirects.read_text(
        encoding="utf-8-sig"
    )

    if START in original or END in original:
        raise RuntimeError(
            "canonical 301 규칙이 이미 있습니다."
        )

    sitemap_tree = ET.parse(sitemap)

    sitemap_urls = {
        url_key(e.text)
        for e in sitemap_tree.getroot().iter()
        if e.tag.rsplit("}", 1)[-1] == "loc"
        and e.text
    }

    sitemap_hosts = {
        host
        for host, path in sitemap_urls
    }

    if len(sitemap_hosts) != 1:
        raise RuntimeError(
            "sitemap 도메인을 확인할 수 없습니다."
        )

    files = sorted(
        p for p in root.rglob("index.html")
        if p.parent.name in IDS
        and p.parent.parent.name == "shops"
    )

    rules = []
    problems = []

    numeric_canonical = 0
    seen_sources = set()

    for source in files:

        text = source.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        canonical = get_canonical(text)

        if not canonical:
            problems.append(
                f"canonical 없음: {source}"
            )
            continue

        parsed = urlsplit(canonical)

        if (
            parsed.scheme not in {"http", "https"}
            or parsed.netloc.lower() not in sitemap_hosts
            or parsed.query
            or parsed.fragment
        ):
            problems.append(
                f"canonical 도메인 또는 형식 오류: {canonical}"
            )
            continue

        public_path = unquote(parsed.path)

        if (
            not public_path.startswith("/")
            or not public_path.endswith("/")
            or "\\" in public_path
            or ".." in public_path.split("/")
        ):
            problems.append(
                f"공개 경로 오류: {canonical}"
            )
            continue

        destination = (
            root
            / public_path.lstrip("/")
            / "index.html"
        )

        if not destination.resolve().is_relative_to(root):
            problems.append(
                f"루트 외부 경로: {canonical}"
            )
            continue

        if destination.resolve() == source.resolve():

            numeric_canonical += 1

            continue

        if not destination.is_file():
            problems.append(
                f"공개파일 없음: {canonical}"
            )
            continue

        if source.read_bytes() != destination.read_bytes():
            problems.append(
                f"원본과 공개파일 내용 다름: {canonical}"
            )
            continue

        if url_key(canonical) not in sitemap_urls:
            problems.append(
                f"canonical sitemap 누락: {canonical}"
            )
            continue

        numeric_path = (
            "/"
            + source.relative_to(root).parent.as_posix()
            + "/"
        )

        numeric_url = (
            parsed.scheme
            + "://"
            + parsed.netloc
            + numeric_path
        )

        if url_key(numeric_url) in sitemap_urls:
            problems.append(
                f"301 출발지가 sitemap에 있음: {numeric_path}"
            )
            continue

        encoded_source = quote(
            numeric_path,
            safe="/-._~"
        )

        encoded_destination = quote(
            public_path,
            safe="/-._~"
        )

        source_key = encoded_source.casefold()

        if source_key in seen_sources:
            problems.append(
                f"301 출발지 중복: {encoded_source}"
            )
            continue

        seen_sources.add(source_key)

        rules.append(
            encoded_source
            + "  "
            + encoded_destination
            + "  301!"
        )

    old_pattern = re.compile(
        r"^/:gu/:dong/shops/\S+/\s+"
        r"/:gu/:dong/shops/00[1-5]/\s+200$"
    )

    preserved = []
    removed_old = 0

    for line in original.splitlines():

        if old_pattern.fullmatch(line.strip()):
            removed_old += 1
        else:
            preserved.append(line)

    existing_sources = set()

    for line in preserved:

        stripped = line.strip()

        if not stripped or stripped.startswith("#"):
            continue

        parts = stripped.split()

        if parts:
            existing_sources.add(
                parts[0].casefold()
            )

    conflicts = sorted(
        seen_sources & existing_sources
    )

    for source in conflicts[:10]:
        problems.append(
            f"기존 리디렉션과 출발지 충돌: {source}"
        )

    if removed_old != 5:
        problems.append(
            f"기존 공통 rewrite 개수 확인 필요: {removed_old}"
        )

    if numeric_canonical + len(rules) != len(files):
        problems.append(
            "업체 페이지와 301 규칙 수가 일치하지 않음"
        )

    print()
    print("===== canonical 301 자동생성 =====")

    print("검사 업체 페이지    :", len(files))
    print("숫자 canonical 유지 :", numeric_canonical)
    print("생성할 301 규칙     :", len(rules))
    print("기존 200 제거       :", removed_old)
    print("기존 규칙 충돌      :", len(conflicts))
    print("문제                :", len(problems))

    if problems:

        for problem in problems[:20]:
            print(problem)

        raise RuntimeError(
            "canonical 301 검사 실패: _redirects를 변경하지 않았습니다."
        )

    block = [
        START,
        *rules,
        END,
        ""
    ]

    updated = (
        "\n".join(block)
        + "\n".join(preserved).rstrip()
        + "\n"
    )

    # 쓰기 전 최종 검증
    lines = updated.splitlines()

    try:
        first = lines.index(START)
        last = lines.index(END)
    except ValueError:
        raise RuntimeError(
            "301 블록 구분자 오류"
        )

    actual_rules = lines[first + 1:last]

    if (
        len(actual_rules) != len(rules)
        or any(
            not line.endswith("  301!")
            for line in actual_rules
        )
    ):
        raise RuntimeError(
            "301 규칙 저장 전 검증 실패"
        )

    backup = (
        root.parent
        / (
            root.name
            + "_redirects_before_factory_301.bak"
        )
    )

    temp = root / "_redirects.factory.tmp"

    if backup.exists() or temp.exists():
        raise RuntimeError(
            "301 백업 또는 임시 파일이 이미 있습니다."
        )

    shutil.copy2(
        redirects,
        backup
    )

    try:

        temp.write_text(
            updated,
            encoding="utf-8"
        )

        os.replace(
            temp,
            redirects
        )

    finally:

        if temp.exists():
            temp.unlink()

    saved = redirects.read_text(
        encoding="utf-8"
    )

    if saved != updated:
        raise RuntimeError(
            "저장된 _redirects 내용 검증 실패"
        )

    print("실제 301 생성       :", len(rules))
    print("저장 후 검증        : 정상")
    print("백업               :", backup)

    return {
        "checked": len(files),
        "created": len(rules),
        "numeric_canonical": numeric_canonical,
        "removed_old": removed_old,
        "verified": True,
        "problems": 0
    }
