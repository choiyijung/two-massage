﻿import re
import html
from pathlib import Path
from collections import defaultdict, Counter
from urllib.parse import urlparse, unquote

ROOT = Path(r"E:\massage-auto-test")

from factory_region_support import path_region

groups = defaultdict(Counter)
depths = Counter()

total = 0
missing_canonical = 0
missing_public_file = 0
name_mismatch = []
public_samples = []

def excluded(p):
    return any(
        x.startswith("_backup")
        or x.startswith("_auto_backup")
        or x in {".git", ".netlify", "node_modules"}
        for x in p.relative_to(ROOT).parts
    )

for p in ROOT.rglob("index.html"):

    if excluded(p):
        continue

    if "shops" not in p.parts:
        continue

    sid = p.parent.name

    if sid not in {"001", "002", "003", "004", "005"}:
        continue

    text = p.read_text(
        encoding="utf-8",
        errors="ignore"
    )

    h1 = re.search(
        r'<h1[^>]*class=["\']ml-test-title["\'][^>]*>(.*?)</h1>',
        text,
        re.I | re.S
    )

    shop = ""

    if h1:
        shop = html.unescape(
            re.sub(r"<[^>]+>", "", h1.group(1))
        ).strip()

    c = re.search(
        r'<link\b[^>]*rel=["\']canonical["\'][^>]*href=["\']([^"\']+)',
        text,
        re.I | re.S
    )

    if not c:
        missing_canonical += 1
        continue

    canonical = html.unescape(c.group(1)).strip()
    parsed = urlparse(canonical)

    region = path_region(parsed.path) or "unclassified"

    groups[(region, sid)][shop] += 1

    relative = p.relative_to(ROOT)
    before_shops = relative.parts.index("shops")
    depths[before_shops] += 1

    public_path = unquote(parsed.path)
    public_file = ROOT / public_path.lstrip("/") / "index.html"

    if not public_file.exists():
        missing_public_file += 1

        if len(public_samples) < 8:
            public_samples.append(
                (str(relative), canonical)
            )

    slug = unquote(
        parsed.path.rstrip("/").split("/")[-1]
    )

    if (
        shop
        and slug not in {
            shop, "001", "002", "003", "004", "005"
        }
    ):
        name_mismatch.append(
            (str(relative), shop, slug)
        )

    total += 1

print("=" * 80)
print("홈페이지 자동제작기 업체 URL 구조 조사")
print("=" * 80)

print("숫자폴더 업체 페이지:", total)
print("canonical 없음:", missing_canonical)
print("canonical 실제경로에 파일 없음:", missing_public_file)
print("업체명과 canonical 이름 불일치:", len(name_mismatch))

print()
print("===== 지역별 업체번호 매핑 =====")

for (region, sid), names in sorted(groups.items()):

    print(
        f"{region:12} | {sid} |",
        ", ".join(
            f"{name}({count})"
            for name, count in names.most_common()
        )
    )

print()
print("===== shops 이전 지역 경로 단계 =====")

for depth, count in sorted(depths.items()):
    print(
        f"{depth}단계 지역 경로:",
        count,
        "페이지"
    )

print()
print("===== 실제 공개경로에 파일이 없는 사례 =====")

for physical, canonical in public_samples:
    print("실제 파일:", physical)
    print("공개 URL :", canonical)
    print()

if name_mismatch:
    print("===== 업체명과 canonical 불일치 사례 =====")

    for x in name_mismatch[:10]:
        print(x)

print()
print("조사 완료")
