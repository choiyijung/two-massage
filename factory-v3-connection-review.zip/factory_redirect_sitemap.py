﻿import os
import shutil
import xml.etree.ElementTree as ET

from pathlib import Path
from urllib.parse import urlsplit, unquote

from factory_public_urls import get_canonical
from factory_canonical_redirects import url_key

MASTER = Path(r"E:\massage-auto-test").resolve()
LIVE = Path(r"E:\seoul-massage-rebuild").resolve()

IDS = {"001", "002", "003", "004", "005"}


def local_name(tag):
    return tag.rsplit("}", 1)[-1]


def prune_numeric_redirect_sources(root):

    root = Path(root).resolve()

    if (
        root == MASTER
        or root.is_relative_to(MASTER)
        or root == LIVE
        or root.is_relative_to(LIVE)
    ):
        raise RuntimeError("마스터 또는 운영 사이트 수정 금지")

    sitemap = root / "sitemap.xml"

    if not sitemap.is_file():
        raise RuntimeError("sitemap.xml 없음")

    tree = ET.parse(sitemap)
    document = tree.getroot()

    if local_name(document.tag) != "urlset":
        raise RuntimeError("sitemap XML 구조 확인 필요")

    entries = {}

    for node in document:

        if local_name(node.tag) != "url":
            continue

        locs = [
            child.text.strip()
            for child in node
            if local_name(child.tag) == "loc"
            and child.text
        ]

        if len(locs) != 1:
            raise RuntimeError("sitemap loc 구조 오류")

        key = url_key(locs[0])

        if key in entries:
            raise RuntimeError(
                "sitemap URL 중복: " + locs[0]
            )

        entries[key] = node

    files = sorted(
        p for p in root.rglob("index.html")
        if p.parent.name in IDS
        and p.parent.parent.name == "shops"
    )

    to_remove = set()
    numeric_canonical = 0
    named_canonical = 0

    canonical_keys = set()
    redirect_sources = set()

    # 먼저 전체 업체 페이지의 canonical 확인
    records = []

    for source in files:

        text = source.read_text(
            encoding="utf-8",
            errors="ignore"
        )

        canonical = get_canonical(text)

        if not canonical:
            raise RuntimeError(
                "canonical 없음: " + str(source)
            )

        parsed = urlsplit(canonical)
        public_path = unquote(parsed.path)

        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.netloc
            or not public_path.startswith("/")
            or not public_path.endswith("/")
            or "\\" in public_path
            or ".." in public_path.split("/")
            or parsed.query
            or parsed.fragment
        ):
            raise RuntimeError(
                "canonical 경로 오류: " + canonical
            )

        destination = (
            root
            / public_path.lstrip("/")
            / "index.html"
        )

        if not destination.resolve().is_relative_to(root):
            raise RuntimeError(
                "공개 경로가 사이트 밖에 있습니다."
            )

        if not destination.is_file():
            raise RuntimeError(
                "공개파일 없음: " + canonical
            )

        if source.read_bytes() != destination.read_bytes():
            raise RuntimeError(
                "공개파일 내용 불일치: " + canonical
            )

        canonical_key = url_key(canonical)

        if canonical_key not in entries:
            raise RuntimeError(
                "대표 URL sitemap 누락: " + canonical
            )

        canonical_keys.add(canonical_key)

        records.append(
            (source, destination, parsed, canonical_key)
        )

    # 업체명 canonical을 사용하는 페이지의 숫자 URL만 수집
    for source, destination, parsed, canonical_key in records:

        if source.resolve() == destination.resolve():
            numeric_canonical += 1
            continue

        named_canonical += 1

        numeric_path = (
            "/"
            + source.relative_to(root).parent.as_posix()
            + "/"
        )

        numeric_url = (
            parsed.scheme
            + "://"
            + parsed.netloc
            + numeric_path
        )

        numeric_key = url_key(numeric_url)

        if numeric_key == canonical_key:
            raise RuntimeError(
                "숫자 URL과 canonical 구분 오류"
            )

        if numeric_key in redirect_sources:
            raise RuntimeError(
                "301 출발지 중복: " + numeric_path
            )

        redirect_sources.add(numeric_key)

        if numeric_key in entries:
            to_remove.add(numeric_key)

    # 다른 업체의 canonical 주소를 제거하지 않도록 확인
    conflicts = to_remove & canonical_keys

    if conflicts:
        raise RuntimeError(
            "301 출발지와 다른 페이지 canonical 충돌: "
            + str(len(conflicts))
        )

    print("=" * 72)
    print("301 대상 숫자 URL sitemap 정리")
    print("=" * 72)

    print("검사 업체 페이지       :", len(files))
    print("숫자 canonical 유지    :", numeric_canonical)
    print("업체명 canonical       :", named_canonical)
    print("기존 sitemap URL       :", len(entries))
    print("sitemap에서 제외할 URL :", len(to_remove))
    print("대표 URL과 충돌        :", len(conflicts))

    if not to_remove:

        print("제외할 숫자 URL이 없습니다.")

        return {
            "removed": 0,
            "remaining": len(entries)
        }

    expected = set(entries) - to_remove

    for key in to_remove:
        document.remove(entries[key])

    # 기존 sitemap의 기본 namespace 보존
    if document.tag.startswith("{"):

        namespace = document.tag.split("}", 1)[0][1:]

        ET.register_namespace("", namespace)

    backup = (
        root.parent
        / (
            root.name
            + "_sitemap_before_301_cleanup.bak"
        )
    )

    temp = root / "sitemap.xml.301.tmp"

    if backup.exists() or temp.exists():
        raise RuntimeError(
            "sitemap 백업 또는 임시 파일이 이미 있습니다."
        )

    tree.write(
        temp,
        encoding="utf-8",
        xml_declaration=True
    )

    verified_tree = ET.parse(temp)

    verified = set()

    for node in verified_tree.getroot().iter():

        if local_name(node.tag) == "loc" and node.text:
            verified.add(url_key(node.text))

    if verified != expected:
        temp.unlink()
        raise RuntimeError(
            "sitemap 저장 전 검증 실패"
        )

    shutil.copy2(sitemap, backup)

    os.replace(temp, sitemap)

    print()
    print("===== sitemap 정리 완료 =====")

    print("제외된 숫자 URL :", len(to_remove))
    print("남은 sitemap URL:", len(verified))
    print("백업 파일       :", backup)

    return {
        "removed": len(to_remove),
        "remaining": len(verified)
    }
