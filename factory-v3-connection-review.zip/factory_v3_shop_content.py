﻿import re
import html
from pathlib import Path
from urllib.parse import urlsplit, unquote
from collections import Counter

BASE = Path(r"D:\massage-sites")

TITLE_RE = re.compile(
    r"<title\b[^>]*>(.*?)</title>",
    re.I | re.S
)

H1_RE = re.compile(
    r"<h1\b[^>]*>(.*?)</h1>",
    re.I | re.S
)

P_RE = re.compile(
    r"(<p\b[^>]*>)(.*?)(</p>)",
    re.I | re.S
)

TOPIC_RE = re.compile(
    r"^(.+?)\s+출장\s+(.+?)\s+마사지$"
)


def clean(value):
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(
        r"\s+", " ",
        html.unescape(value)
    ).strip()


def canonical(text):
    for tag in re.findall(
        r"<link\b[^>]*>",
        text,
        re.I | re.S
    ):
        if re.search(
            r'\brel\s*=\s*["\']canonical["\']',
            tag,
            re.I
        ):
            match = re.search(
                r'\bhref\s*=\s*(["\'])(.*?)\1',
                tag,
                re.I | re.S
            )

            if match:
                return html.unescape(match.group(2))

    return ""


def canonical_path(root, url):
    path = unquote(
        urlsplit(url).path
    ).lstrip("/")

    if not path:
        return root / "index.html"

    if path.endswith("/"):
        return root / path / "index.html"

    if path.endswith(".html"):
        return root / path

    return root / path / "index.html"


def class_name(tag):
    match = re.search(
        r'\bclass\s*=\s*(["\'])(.*?)\1',
        tag,
        re.I | re.S
    )

    if not match:
        return []

    return match.group(2).split()


def inspect_shop(root, path, profile):
    text = path.read_text(
        encoding="utf-8",
        errors="strict"
    )

    title_match = TITLE_RE.search(text)
    h1_match = H1_RE.search(text)

    if not title_match or not h1_match:
        raise ValueError("TITLE 또는 H1 없음")

    old_title = clean(
        title_match.group(1)
    )

    shop = clean(
        h1_match.group(1)
    )

    topic = old_title.split("|")[0].strip()

    match = TOPIC_RE.fullmatch(topic)

    if not match:
        raise ValueError(
            "지역·마사지 유형 추출 실패: " + topic
        )

    area = match.group(1).strip()
    treatment = match.group(2).strip()

    paragraphs = list(
        P_RE.finditer(text)
    )

    short_intro = []
    long_intro = []

    for paragraph in paragraphs:
        classes = class_name(
            paragraph.group(1)
        )

        if "ml-test-intro" in classes:
            short_intro.append(paragraph)

        if "ml-copy" in classes:
            long_intro.append(paragraph)

    if len(short_intro) != 1:
        raise ValueError(
            f"상단 소개문 개수: {len(short_intro)}"
        )

    if len(long_intro) != 2:
        raise ValueError(
            f"ml-copy 개수: {len(long_intro)}"
        )

    if not shop or not area or not treatment:
        raise ValueError(
            "업체명·지역·마사지 유형 중 빈 값"
        )

    if profile == "A":
        new_title = (
            f"{shop} | {area} 출장 "
            f"{treatment} 마사지 코스와 지역 안내"
        )

        new_description = (
            f"{shop}의 {area} 출장 "
            f"{treatment} 마사지 정보를 살펴보세요. "
            "페이지에 안내된 코스와 이용시간을 "
            "비교하고 문의 전 필요한 내용을 "
            "확인할 수 있습니다."
        )

        new_short = (
            f"{shop} · {area} 출장 "
            f"{treatment} 마사지 이용정보"
        )

        new_long = (
            f"{area}에서 {shop}의 출장 "
            f"{treatment} 마사지 코스를 "
            "알아보는 분들을 위해 이용정보를 "
            "정리했습니다. "
            "페이지에 표시된 코스별 시간과 "
            "구성을 비교하고 원하는 이용 내용을 "
            "확인해보세요. "
            "이용하려는 위치와 희망 시간에 따라 "
            "문의할 사항을 미리 정리할 수 있습니다. "
            "실제 예약 가능 여부는 업체 문의를 "
            "통해 확인해 주세요."
        )

    else:
        new_title = (
            f"출장 {treatment} 마사지 "
            f"{area} 이용안내 | "
            f"{shop} 코스·예약 전 확인"
        )

        new_description = (
            f"출장 {treatment} 마사지를 "
            f"{area}에서 알아보고 있다면 "
            f"{shop}의 코스 구성부터 확인해보세요. "
            "희망 시간과 방문 위치를 정리한 뒤 "
            "이용 가능 여부를 문의할 수 있습니다."
        )

        new_short = (
            f"출장 {treatment} 마사지 "
            f"코스·문의 안내 | {area} {shop}"
        )

        new_long = (
            f"출장 {treatment} 마사지 이용을 "
            "준비할 때는 코스표에 안내된 "
            "시간과 구성을 먼저 살펴보세요. "
            f"{area}에서 {shop} 이용을 "
            "알아보고 있다면 원하는 코스를 "
            "정한 다음 날짜와 시간대를 "
            "함께 확인하는 방법이 있습니다. "
            "문의 전에 이용할 위치와 궁금한 "
            "사항을 정리하면 안내 내용을 "
            "확인하기 편리합니다. "
            "실제 이용 가능 시간과 세부 조건은 "
            "상담 시 확인해 주세요."
        )

    url = canonical(text)

    if not url:
        raise ValueError("canonical 없음")

    named_path = canonical_path(
        root,
        url
    )

    is_named = (
        named_path.resolve()
        != path.resolve()
    )

    if is_named:
        if not named_path.is_file():
            raise ValueError(
                "대표 URL 파일 없음: " + str(named_path)
            )

        named_text = named_path.read_text(
            encoding="utf-8",
            errors="strict"
        )

        if named_text != text:
            raise ValueError(
                "숫자 URL과 업체명 URL의 HTML이 서로 다름"
            )

    return {
        "title": new_title,
        "description": new_description,
        "short": new_short,
        "long": new_long,
        "named": is_named,
        "old_title": old_title,
    }


def main():
    for profile in ("A", "B"):
        root = BASE / f"massage-v3-{profile}"

        if not root.is_dir():
            raise RuntimeError(
                f"사이트 없음: {root}"
            )

        stats = Counter()
        failures = []
        examples = []

        titles = Counter()
        descriptions = Counter()

        files = sorted(
            path
            for path in root.rglob("index.html")
            if (
                "shops" in path.relative_to(root).parts
                and path.parent.name.isdigit()
            )
        )

        for path in files:
            relative = path.relative_to(
                root
            ).as_posix()

            stats["검사"] += 1

            try:
                result = inspect_shop(
                    root,
                    path,
                    profile
                )

                stats["성공"] += 1

                if result["named"]:
                    stats["업체명 대표 URL"] += 1
                else:
                    stats["숫자 대표 URL"] += 1

                titles[result["title"]] += 1
                descriptions[result["description"]] += 1

                if len(examples) < 3:
                    examples.append(
                        (relative, result)
                    )

            except Exception as exc:
                stats["실패"] += 1

                if len(failures) < 15:
                    failures.append(
                        (relative, str(exc))
                    )

        print()
        print("=" * 70)
        print("V3 업체 콘텐츠 사전검사:", profile)
        print("=" * 70)

        for key in (
            "검사",
            "성공",
            "실패",
            "업체명 대표 URL",
            "숫자 대표 URL",
        ):
            print(key + ":", stats[key])

        print(
            "새 TITLE 중복:",
            sum(
                n - 1
                for n in titles.values()
                if n > 1
            )
        )

        print(
            "새 DESCRIPTION 중복:",
            sum(
                n - 1
                for n in descriptions.values()
                if n > 1
            )
        )

        print()
        print("생성 샘플")

        for relative, result in examples:
            print()
            print("파일:", relative)
            print("TITLE:", result["title"])
            print(
                "DESCRIPTION:",
                result["description"]
            )
            print(
                "상단 소개:",
                result["short"]
            )
            print(
                "긴 소개:",
                result["long"][:180]
            )

        print()
        print("실패 사례")

        for relative, reason in failures:
            print(relative)
            print("사유:", reason)

    print()
    print("검사 완료")
    print("A/B 홈페이지 HTML 수정 없음")


if __name__ == "__main__":
    main()
